import shapes.*;

/**
 * Lid - Representa la tapa de una taza.
 * 
 * Visualmente es un rectángulo plano de 1 cm de alto que se coloca
 * encima de su taza correspondiente:
 * 
 *   [_________]   <- tapa (Lid) - rectángulo sólido, 1 cm alto
 *   |         |
 *   |_________|   <- taza (Cup)
 * 
 * Cada tapa tiene el mismo ancho que su taza y el mismo color.
 * El índice cupIndex indica a qué taza pertenece.
 *
 * @author Mabel Bernal, Jeronimo Avila
 * @version Ciclo 1
 */
public class Lid {

    // Constantes 

    // Posición inicial de cualquier Rectangle en shapes
    private static final int SHAPE_START_X = 70;
    private static final int SHAPE_START_Y = 15;

    //  Atributos

    private int    cupIndex; // Índice de la taza a la que pertenece esta tapa
    private String color;    // Color (igual que el de su taza)

    // Representación visual: un solo rectángulo plano
    private Rectangle body;

    //  Rastreo de posición
    // (mismo mecanismo que en Cup: guardamos dónde cree shapes que está)

    private int curX = SHAPE_START_X, curY = SHAPE_START_Y; // dónde queremos que esté
    private int bX   = SHAPE_START_X, bY   = SHAPE_START_Y; // dónde shapes cree que está

    private boolean isVisible = false;

    // Constructor 

    /**
     * Crea una tapa para la taza indicada.
     *
     * @param cupIndex índice de la taza a la que pertenece (>= 1)
     * @param color    color de la tapa (debe ser igual al de su taza)
     */
    public Lid(int cupIndex, String color) {
        this.cupIndex = cupIndex;
        this.color    = color;

        // Creamos un solo rectángulo para la tapa
        body = new Rectangle();
        body.changeColor(color);

        // Alto = 1 cm convertido a píxeles, ancho = mismo que la taza
        // Cup.PX_PER_CM nos da la escala (10 píxeles por cm)
        body.changeSize(Cup.PX_PER_CM, getPixelWidth()); // changeSize(alto, ancho)
    }
    // VisibilidaD
    /**
     * Muestra la tapa en el canvas.
     */
    public void makeVisible() {
        if (!isVisible) {
            // primero mover a posición correcta
            moveShape(curX, curY);
            isVisible = true;           
            body.makeVisible();
        }
    }
    /**
     * Oculta la tapa del canvas.
     */
    public void makeInvisible() {
        if (isVisible) {
            body.makeInvisible();
            isVisible = false;
        }
    }
    //Movimiento 
    /**
     * Mueve la tapa a la posición (x, y) en píxeles.
     * Funciona igual que en Cup: guarda la posición y mueve si está visible.
     *
     * @param x posición horizontal destino
     * @param y posición vertical destino
     */
    public void moveTo(int x, int y) {
        curX = x;
        curY = y;
        if (isVisible) moveShape(x, y);
    }
    /**
     * Mueve físicamente el rectángulo usando deltas.
     */
    private void moveShape(int x, int y) {
        body.moveHorizontal(x - bX); // delta horizontal
        body.moveVertical  (y - bY); // delta vertical
        bX = x; bY = y;              // actualizar posición guardada
    }
    // Getters 
    /** La tapa siempre mide 1 cm de alto */
    public int getHeight()     { return 1; }

    /** Retorna el índice de la taza a la que pertenece esta tapa */
    public int getCupIndex()   { return cupIndex; }

    /** Retorna el color de la tapa */
    public String getColor()   { return color; }
    /**
     * Retorna el ancho en píxeles.
     * Usa la misma fórmula que Cup.getPixelWidth() para que
     * la tapa tenga exactamente el mismo ancho que su taza.
     */
    public int getPixelWidth() { return 30 + (cupIndex * 20); }
}
