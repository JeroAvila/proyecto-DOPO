import shapes.*;

/**
 * Cup - Representa una taza cilíndrica vista de frente.
 * 
 * Visualmente se dibuja como una "U":
 *   |       |   <- pared izquierda y derecha
 *   |_______|   <- base
 * 
 * La taza número i tiene altura = 2^(i-1) cm.
 * Por ejemplo: taza 1 = 1cm, taza 2 = 2cm, taza 3 = 4cm, taza 4 = 8cm.
 * 
 * Cada taza se dibuja con 3 rectángulos de la librería shapes:
 * leftWall (pared izquierda), rightWall (pared derecha) y base.
 *
 * @author Mabel Bernal, Jeronimo Avila
 * @version Ciclo 1
 */
public class Cup {

    // Constantes

    // Cuántos píxeles equivalen a 1 cm en pantalla.
    // Si PX_PER_CM = 10, entonces 1 cm = 10 píxeles.
    public static final int PX_PER_CM = 10;

    // Grosor fijo de las paredes laterales en píxeles.
    private static final int WALL_W = 8;

    // Grosor fijo de la base en píxeles.
    private static final int BASE_H = 6;

    // La librería shapes crea todos los rectángulos en la posición (70, 15).
    // Guardamos esto para calcular bien los desplazamientos.
    private static final int SHAPE_START_X = 70;
    private static final int SHAPE_START_Y = 15;

    // Atributos lógicos 

    private int    index;   // Número de la taza (1, 2, 3, 4...)
    private int    height;  // Altura en cm = 2^(index-1)
    private String color;   // Color de la taza ("red", "blue", etc.)
    private boolean covered; // true si la taza tiene su tapa encima (Ciclo 2)

    //  Atributos visuales 
    // Los 3 rectángulos que forman la forma de U
    private Rectangle leftWall;   // Pared izquierda
    private Rectangle rightWall;  // Pared derecha
    private Rectangle base;       // Base inferior

    //Rastreo de posición
    // shapes no tiene getX()/getY(), así que guardamos la posición
    // actual nosotros mismos para poder calcular el delta de movimiento.

    // Posición donde QUEREMOS que esté la taza (bounding box superior izquierda)
    private int curX = SHAPE_START_X;
    private int curY = SHAPE_START_Y;

    // Posición donde shapes CREE que está cada rectángulo
    // (empieza en SHAPE_START porque así los crea la librería)
    private int lwX = SHAPE_START_X, lwY = SHAPE_START_Y; // leftWall
    private int rwX = SHAPE_START_X, rwY = SHAPE_START_Y; // rightWall
    private int bX  = SHAPE_START_X, bY  = SHAPE_START_Y; // base

    // Si la taza está siendo mostrada en pantalla o no
    private boolean isVisible = false;

    // Constructor 

    /**
     * Crea una taza con el índice y color dados.
     * Calcula su altura y prepara los 3 rectángulos con el tamaño correcto.
     *
     * @param index número de la taza (debe ser >= 1)
     * @param color color de la taza ("red", "blue", "green", etc.)
     */
    public Cup(int index, String color) {
        this.index   = index;
        this.height  = (int) Math.pow(2, index - 1); // 2^(index-1) cm
        this.color   = color;
        this.covered = false; // al crear, la taza no está tapada

        // Calculamos las dimensiones en píxeles
        int totalW = getPixelWidth();           // ancho total de la taza
        int totalH = height * PX_PER_CM;       // alto total en píxeles
        int wallH  = totalH - BASE_H;          // las paredes no incluyen la base

        // Creamos la pared izquierda
        leftWall = new Rectangle();
        leftWall.changeColor(color);
        leftWall.changeSize(wallH, WALL_W); // changeSize(alto, ancho)

        // Creamos la pared derecha (mismo tamaño que la izquierda)
        rightWall = new Rectangle();
        rightWall.changeColor(color);
        rightWall.changeSize(wallH, WALL_W);

        // Creamos la base (más baja, ocupa todo el ancho)
        base = new Rectangle();
        base.changeColor(color);
        base.changeSize(BASE_H, totalW);
    }
    // Visibilidad
    /**
     * Muestra la taza en el canvas.
     * Primero la mueve a la posición correcta, luego la hace visible.
     */
    public void makeVisible() {
        if (!isVisible) {
            moveShapes(curX, curY);
            // Mover a la posición guardada antes de mostrar           
            isVisible = true;
            leftWall.makeVisible();
            rightWall.makeVisible();
            base.makeVisible();
        }
    }
    /**
     * Oculta la taza del canvas.
     */
    public void makeInvisible() {
        if (isVisible) {
            leftWall.makeInvisible();
            rightWall.makeInvisible();
            base.makeInvisible();
            isVisible = false;
        }
    }
    //  Movimiento
    /**
     * Mueve la taza a la posición (x, y) en píxeles.
     * (x, y) es la esquina superior izquierda del bounding box.
     * Si la taza no está visible, guarda la posición para usarla al hacerse visible.
     *
     * @param x posición horizontal en píxeles
     * @param y posición vertical en píxeles
     */
    public void moveTo(int x, int y) {
        curX = x;
        curY = y;
        // Solo mover físicamente si está visible
        if (isVisible) moveShapes(x, y);
    }
    /**
     * Mueve los 3 rectángulos a la posición correcta.
     * 
     * Como shapes solo tiene moveHorizontal(delta) y moveVertical(delta),
     * calculamos cuánto hay que mover desde donde estaban antes (delta = destino - origen).
     *
     * @param x posición horizontal destino
     * @param y posición vertical destino
     */
    private void moveShapes(int x, int y) {
        int totalW = getPixelWidth();
        int totalH = height * PX_PER_CM;
        // Pared izquierda: va en la esquina superior izquierda
        int targetLwX = x;
        int targetLwY = y;

        // Pared derecha: va en el extremo derecho (ancho total - grosor de pared)
        int targetRwX = x + totalW - WALL_W;
        int targetRwY = y;

        // Base: va en la parte inferior (alto total - grosor de base)
        int targetBX = x;
        int targetBY = y + totalH - BASE_H;

        // Mover cada rectángulo usando deltas (destino - posición actual)
        leftWall.moveHorizontal(targetLwX - lwX);
        leftWall.moveVertical  (targetLwY - lwY);
        lwX = targetLwX; lwY = targetLwY; // actualizar posición guardada

        rightWall.moveHorizontal(targetRwX - rwX);
        rightWall.moveVertical  (targetRwY - rwY);
        rwX = targetRwX; rwY = targetRwY;

        base.moveHorizontal(targetBX - bX);
        base.moveVertical  (targetBY - bY);
        bX = targetBX; bY = targetBY;
    }
    //  Ciclo 2: estado de tapado
    /**
     * CICLO 2 - Cambia el estado de tapado de la taza.
     * Cuando está tapada, cambia su color a negro para que luzca diferente.
     * Cuando se destapa, vuelve a su color original.
     * Esto cumple el requisito: "las tazas tapadas deben lucir diferentes".
     *
     * @param covered true para tapar, false para destapar
     */
    public void setCovered(boolean covered) {
        this.covered = covered;
        // Si está tapada mostramos negro, si no, el color original
        String displayColor = covered ? "black" : color;
        leftWall.changeColor(displayColor);
        rightWall.changeColor(displayColor);
        base.changeColor(displayColor);
    }
    //  Getters 
    /** Retorna si la taza está tapada (Ciclo 2) */
    public boolean isCovered()  { return covered; }
    /** Retorna la altura de la taza en cm */
    public int getHeight()      { return height; }
    /** Retorna el número/índice de la taza */
    public int getIndex()       { return index; }
    /** Retorna el color de la taza */
    public String getColor()    { return color; }
    /**
     * Retorna el ancho total de la taza en píxeles.
     * El ancho crece con el índice para simular que las tazas
     * más grandes tienen mayor diámetro.
     * taza 1 = 50px, taza 2 = 70px, taza 3 = 90px, taza 4 = 110px
     */
    public int getPixelWidth()  { return 30 + (index * 20); }
}
