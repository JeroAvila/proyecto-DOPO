import static org.junit.Assert.*;
import org.junit.*;

/**
 * TowerC2Test - Pruebas de unidad para el Ciclo 2.
 * 
 * IMPORTANTE: Todas las pruebas corren en modo INVISIBLE.
 * Esto significa que NO llamamos makeVisible() en ningún test.
 * 
 * Cada prueba verifica UNA cosa específica.
 * Convención de nombre: accordingBAShould_[descripción]
 * (BA = iniciales de Bernal y Avila, orden alfabético)
 * 
 * Cada prueba tiene dos preguntas en mente:
 *   ¿Qué DEBERÍA hacer? → pruebas positivas (assert con true/valor esperado)
 *   ¿Qué NO debería hacer? → pruebas negativas (assert con false/ok()==false)
 *
 * @author Mabel Bernal, Jeronimo Avila
 * @version Ciclo 2
 */
public class TowerC2Test {

    // La torre que usamos en cada prueba
    private Tower tower;

    /**
     * Se ejecuta ANTES de cada prueba.
     * Crea una torre nueva vacía para que cada test empiece limpio.
     */
    @Before
    public void setUp() {
        tower = new Tower(10, 20);
    }

    /**
     * Se ejecuta DESPUÉS de cada prueba.
     * Limpia la torre para liberar recursos.
     */
    @After
    public void tearDown() {
        tower.exit();
    }
    //test adcionales
     /**
     * swap(cup4, cup4) no debe cambiar el orden
     * del stack ni generar error.
     */
    @Test
    public void accordingBAShould_SwapSameObjectDoesNotChangeStack() {
        tower.pushCup(4);
        tower.pushCup(2);
        String[][] before = tower.stackingItems();
        tower.swap(new String[]{"cup", "4"}, new String[]{"cup", "4"});
        assertTrue("swap consigo mismo debe ser exitoso", tower.ok());
        String[][] after = tower.stackingItems();
        assertEquals("El primer elemento no debe cambiar",
                     before[0][1], after[0][1]);
        assertEquals("El segundo elemento no debe cambiar",
                     before[1][1], after[1][1]);
    }

    /**
     * Si hay tapa para la taza 4 pero no para
     * la taza 2, cover() solo debe marcar la taza 4 como tapada.
     */
    @Test
    public void accordingBAShould_CoverOnlyMatchingCupsNotAll() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.pushLid(4);
        tower.cover();
        assertTrue("Taza 4 debe estar tapada", tower.isCupCovered(4));
        assertFalse("Taza 2 NO debe estar tapada", tower.isCupCovered(2));
    }

    /**
     * debe funcionar
     * correctamente cuando hay tapas mezcladas en el stack,
     * y el swap sugerido debe reducir la altura al aplicarse.
     */
    @Test
    public void accordingBAShould_SwapToReduceWithLidsInStack() {
        tower.pushCup(1);
        tower.pushLid(1);
        tower.pushCup(4);
        int heightBefore = tower.height();
        String[][] swap = tower.swapToReduce();
        assertTrue("swapToReduce con tapas debe completarse sin error", tower.ok());
        if (swap != null) {
            tower.swap(swap[0], swap[1]);
            assertTrue("El swap sugerido debe reducir la altura",
                       tower.height() < heightBefore);
        }
    }

    /**
     * Una tapa cuya taza NO está en el stack
     * se posiciona en 0, su contribución a la altura es 1 cm.
     */
    @Test
    public void accordingBAShould_LidAloneGivesHeightOne() {
        tower.pushLid(4);
        assertEquals("Una tapa sola debe dar altura 1 cm", 1, tower.height());
    }

    /**
     * Tower(3) debe crear las tazas en el
     * orden cup3, cup2, cup1 (mayor a menor en el stack).
     */
    @Test
    public void accordingBAShould_TowerCupsConstructorCreatesInOrder() {
        Tower t = new Tower(3);
        String[][] items = t.stackingItems();
        assertEquals("Primer elemento debe ser la taza 3", "3", items[0][1]);
        assertEquals("Segundo elemento debe ser la taza 2", "2", items[1][1]);
        assertEquals("Tercer elemento debe ser la taza 1", "1", items[2][1]);
        t.exit();
    }

    /**
     * reverseTower() debe invertir el orden
     * de tazas y tapas mezcladas, no solo las tazas.
     */
    @Test
    public void accordingBAShould_ReverseMixedStackInvertsAll() {
        tower.pushCup(4);
        tower.pushLid(4);
        tower.pushCup(2);
        tower.reverseTower();
        String[][] items = tower.stackingItems();
        assertEquals("cup2 debe quedar primera", "2", items[0][1]);
        assertEquals("cup4 debe quedar última", "4", items[2][1]);
    }
    // REQUISITO 10 - Tower(cups)
    // Pruebas del constructor que crea tazas automáticamente
    /**
     * Tower(4) debe crear exactamente 4 tazas.
     */
    @Test
    public void accordingBAShould_CreateTowerWithExactNumberOfCups() {
        Tower t = new Tower(4);
        // Contar cuántos objetos de tipo "cup" hay en el stack
        String[][] items = t.stackingItems();
        int cupCount = 0;
        for (String[] item : items) {
            if (item[0].equals("cup")) cupCount++;
        }
        assertEquals("Deben existir exactamente 4 tazas", 4, cupCount);
        t.exit();
    }

    /**
     * ¿Tower(4) NO debe incluir tapas.
     */
    @Test
    public void accordingBAShould_NotHaveLidsWhenCreatedWithCupsConstructor() {
        Tower t = new Tower(4);
        assertEquals("No deben existir tapas al crear con Tower(cups)", 0, t.lidedCups().length);
        t.exit();
    }

    /**
     * Tower(4) debe tener las tazas 1, 2, 3 y 4.
     */
    @Test
    public void accordingBAShould_CreateCupsWithCorrectIndexes() {
        Tower t = new Tower(4);
        String[][] items = t.stackingItems();
        boolean has1 = false, has2 = false, has3 = false, has4 = false;
        for (String[] item : items) {
            if (item[0].equals("cup")) {
                switch (item[1]) {
                    case "1": has1 = true; break;
                    case "2": has2 = true; break;
                    case "3": has3 = true; break;
                    case "4": has4 = true; break;
                }
            }
        }
        assertTrue("Deben existir las tazas 1, 2, 3 y 4", has1 && has2 && has3 && has4);
        t.exit();
    }
    // REQUISITO 11 - swap
    // Pruebas de intercambio de objetos en el stack
    /**
     * swap debe cambiar el orden de dos tazas en el stack.
     */
    @Test
    public void accordingBAShould_SwapTwoCupsAndChangeOrder() {
        tower.pushCup(4);
        tower.pushCup(2);

        // Antes del swap: stack = [cup4, cup2]
        tower.swap(new String[]{"cup", "4"}, new String[]{"cup", "2"});

        assertTrue("La operación swap debe ser exitosa", tower.ok());

        // Después del swap: stack = [cup2, cup4]
        String[][] items = tower.stackingItems();
        assertEquals("La taza 2 debe estar primera después del swap", "2", items[0][1]);
    }

    /**
     * swap debe funcionar entre una taza y una tapa.
     */
    @Test
    public void accordingBAShould_SwapCupWithLid() {
        tower.pushCup(4);
        tower.pushLid(4);
        tower.swap(new String[]{"cup", "4"}, new String[]{"lid", "4"});
        assertTrue("swap entre taza y tapa debe ser exitoso", tower.ok());
    }

    /**
     * swap NO debe funcionar si un objeto no existe.
     */
    @Test
    public void accordingBAShould_NotSwapIfObjectDoesNotExist() {
        tower.pushCup(4);
        // La taza 99 no existe en la torre
        tower.swap(new String[]{"cup", "4"}, new String[]{"cup", "99"});
        assertFalse("swap con objeto inexistente debe fallar", tower.ok());
    }

    /**
     * swap NO debe funcionar si el stack está vacío.
     */
    @Test
    public void accordingBAShould_NotSwapOnEmptyTower() {
        tower.swap(new String[]{"cup", "1"}, new String[]{"cup", "2"});
        assertFalse("swap en torre vacía debe fallar", tower.ok());
    }
    // REQUISITO 12 - cover
    // Pruebas de tapado de tazas
    /**
     * cover debe ejecutarse sin error cuando hay tapas.
     */
    @Test
    public void accordingBAShould_CoverSuccessfullyWhenLidsExist() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.pushLid(4); // tapa para la taza 4
        tower.cover();
        assertTrue("cover debe ser exitoso cuando hay tapas", tower.ok());
    }

    /**
     * cover debe funcionar aunque no haya tapas.
     */
    @Test
    public void accordingBAShould_CoverSuccessfullyWithNoLids() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.cover(); // no hay tapas, pero no debe fallar
        assertTrue("cover sin tapas no debe generar error", tower.ok());
    }

    /**
     * cover debe funcionar aunque la torre esté vacía.
     */
    @Test
    public void accordingBAShould_CoverOnEmptyTower() {
        tower.cover();
        assertTrue("cover en torre vacía no debe generar error", tower.ok());
    }
    // REQUISITO 13 - swapToReduce
    // Pruebas de consulta de intercambio que reduce altura
    /**
     * swapToReduce no debe modificar la torre.
     * La altura antes y después de llamarlo debe ser la misma.
     */
    @Test
    public void accordingBAShould_NotModifyTowerWhenCallingSwapToReduce() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.pushCup(3);
        int heightBefore = tower.height();

        tower.swapToReduce(); // solo consulta, no modifica

        assertEquals("swapToReduce no debe cambiar la altura", heightBefore, tower.height());
    }

    /**
     * Si existe un swap que reduce la altura,
     * aplicarlo debe resultar en una altura menor.
     */
    @Test
    public void accordingBAShould_ReturnSwapThatActuallyReducesHeight() {
        // Orden no óptimo: taza pequeña primero
        tower.pushCup(1);
        tower.pushCup(4);
        int before = tower.height();

        String[][] swap = tower.swapToReduce();
        if (swap != null) {
            // Aplicar el swap sugerido
            tower.swap(swap[0], swap[1]);
            assertTrue("Aplicar el swap sugerido debe reducir la altura",
                       tower.height() < before);
        }
        assertTrue("swapToReduce debe completarse sin error", tower.ok());
    }

    /**
     * Con una sola taza no hay intercambio posible,
     * debe retornar null.
     */
    @Test
    public void accordingBAShould_ReturnNullIfNoSwapReducesHeight() {
        tower.pushCup(4); // una sola taza, no hay nada que intercambiar
        String[][] result = tower.swapToReduce();
        assertNull("Con una sola taza no hay swap posible, debe retornar null", result);
    }
    // Pruebas generales heredadas del Ciclo 1
    /**
     * La torre vacía debe tener altura 0.
     */
    @Test
    public void accordingBAShould_HaveZeroHeightWhenEmpty() {
        assertEquals("Torre vacía debe tener altura 0", 0, tower.height());
    }

    /**
     * pushCup con índice 0 o negativo debe fallar.
     */
    @Test
    public void accordingBAShould_NotAcceptInvalidCupIndex() {
        tower.pushCup(0);
        assertFalse("pushCup(0) debe fallar", tower.ok());
    }

    /**
     * popCup en torre vacía debe fallar.
     */
    @Test
    public void accordingBAShould_NotPopFromEmptyTower() {
        tower.popCup();
        assertFalse("popCup en torre vacía debe fallar", tower.ok());
    }

    /**
     * El ejemplo del ICPC: pushCup(4), pushCup(2), pushCup(3), pushCup(1)
     * debe dar altura 9 cm.
     */
    @Test
    public void accordingBAShould_ComputeCorrectHeightForICPCExample() {
        tower.pushCup(4); // 8 cm
        tower.pushCup(2); // cae dentro de 4
        tower.pushCup(3); // cae dentro de 4
        tower.pushCup(1); // cae dentro de 3
        assertEquals("El ejemplo ICPC debe dar altura 8", 8, tower.height());
    }

    /**
     * orderTower debe dejar la taza de mayor índice primero en el stack.
     */
    @Test
    public void accordingBAShould_OrderTowerWithLargestCupFirst() {
        tower.pushCup(1);
        tower.pushCup(3);
        tower.pushCup(2);
        tower.orderTower();
        String[][] items = tower.stackingItems();
        assertEquals("La taza más grande debe quedar primera", "3", items[0][1]);
    }

    /**
     * reverseTower debe invertir el orden del stack.
     */
    @Test
    public void accordingBAShould_ReverseTowerOrder() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.reverseTower();
        String[][] items = tower.stackingItems();
        // Después de invertir, la taza 2 debe quedar primera
        assertEquals("Después de reverse, la taza 2 debe estar primera", "2", items[0][1]);
    }
// REQUISITO 10 - Tower(cups) — pruebas faltantes
/**
 * Tower(4) debe crear una torre cuya
 * altura total sea 8 cm, que es la altura de la taza 4
 * (la más grande, 2^3 = 8 cm). Las demás caen dentro.
 */
@Test
public void accordingBAShould_CreateCupsWithCorrectHeights() {
    Tower t = new Tower(4);
    assertEquals("Tower(4) debe tener altura 8 cm", 8, t.height());
    t.exit();
}
/**
 * Tower(1) no debe crear tapas,
 * solo la taza 1. El constructor no incluye tapas.
 */
@Test
public void accordingBAShould_NotHaveLidsWithSingleCupConstructor() {
    Tower t = new Tower(1);
    assertEquals("Tower(1) no debe tener tapas", 0, t.lidedCups().length);
    t.exit();
}
/**
 * Tower(1) debe crear exactamente
 * 1 objeto en el stack, de tipo taza con índice 1.
 */
@Test
public void accordingBAShould_CreateOneCupWithCorrectIndex() {
    Tower t = new Tower(1);
    String[][] items = t.stackingItems();
    assertEquals("Tower(1) debe tener 1 objeto", 1, items.length);
    assertEquals("El objeto debe ser una taza", "cup", items[0][0]);
    assertEquals("La taza debe tener índice 1", "1", items[0][1]);
    t.exit();
}
// REQUISITO 11 - swap — pruebas faltantes
/**
 * Hacer swap de un objeto consigo mismo
 * debe ser exitoso y no cambiar el orden del stack.
 */
@Test
public void accordingBAShould_SwapSameObjectKeepsStackUnchanged() {
    tower.pushCup(4);
    tower.pushCup(2);
    String[][] before = tower.stackingItems();
    tower.swap(new String[]{"cup", "4"}, new String[]{"cup", "4"});
    assertTrue("swap consigo mismo debe ser exitoso", tower.ok());
    String[][] after = tower.stackingItems();
    assertEquals("El stack no debe cambiar", before[0][1], after[0][1]);
}

/**
 * Después de swap, stackingItems() debe
 * reflejar el nuevo orden. Se intercambian cup3 y cup2,
 * entonces cup2 queda primera y cup3 queda última.
 */
@Test
public void accordingBAShould_StackingItemsReflectsSwapOrder() {
    tower.pushCup(3);
    tower.pushCup(1);
    tower.pushCup(2);
    tower.swap(new String[]{"cup", "3"}, new String[]{"cup", "2"});
    String[][] items = tower.stackingItems();
    assertEquals("cup2 debe estar primera", "2", items[0][1]);
    assertEquals("cup3 debe estar última", "3", items[2][1]);
}
/**
 * swap con dos objetos que no existen
 * en la torre debe fallar y ok() debe retornar false.
 */
@Test
public void accordingBAShould_NotSwapBothObjectsMissing() {
    tower.pushCup(1);
    tower.swap(new String[]{"cup", "88"}, new String[]{"cup", "99"});
    assertFalse("swap con ambos objetos inexistentes debe fallar", tower.ok());
}
// REQUISITO 12 - cover — pruebas faltantes
/**
 * Después de cover(), una taza que tiene
 * su tapa en la torre debe quedar marcada como tapada.
 * Usa isCupCovered() para verificarlo.
 */
@Test
public void accordingBAShould_MarkCupAsCoveredWhenLidExists() {
    tower.pushCup(4);
    tower.pushLid(4);
    tower.cover();
    assertTrue("La taza 4 debe estar tapada", tower.isCupCovered(4));
}

/**
 * Una taza que no tiene su tapa
 * en la torre NO debe quedar marcada como tapada después
 * de llamar cover().
 */
@Test
public void accordingBAShould_NotMarkCupAsCoveredWithoutLid() {
    tower.pushCup(4);
    tower.pushCup(2);
    tower.pushLid(4); // solo hay tapa para la taza 4, no para la 2
    tower.cover();
    assertFalse("La taza 2 NO debe estar tapada", tower.isCupCovered(2));
}

/**
 * cover() debe tapar SOLO las tazas que
 * tienen su tapa, sin afectar a las demás. Aquí cup4 tiene
 * tapa pero cup2 no, entonces solo cup4 queda tapada.
 */
@Test
public void accordingBAShould_CoverOnlyMatchingCups() {
    tower.pushCup(4);
    tower.pushCup(2);
    tower.pushLid(4);
    tower.cover();
    assertTrue("La taza 4 debe estar tapada", tower.isCupCovered(4));
    assertFalse("La taza 2 NO debe estar tapada", tower.isCupCovered(2));
}

/**
 * isCupCovered() debe retornar false
 * para una taza que no existe en la torre.
 */
@Test
public void accordingBAShould_ReturnFalseForNonExistentCupInCovered() {
    tower.pushCup(4);
    tower.cover();
    assertFalse("Taza inexistente no puede estar tapada", tower.isCupCovered(99));
}
// REQUISITO 13 - swapToReduce — pruebas faltantes
/**
 *  Si la torre ya está en orden óptimo
 * (taza grande primero, pequeñas dentro), swapToReduce()
 * debe retornar null porque ningún swap mejoraría la altura.
 */
@Test
public void accordingBAShould_ReturnNullWhenTowerAlreadyOptimal() {
    tower.pushCup(4);
    tower.pushCup(2);
    tower.pushCup(1);
    String[][] result = tower.swapToReduce();
    assertNull("Torre óptima debe retornar null", result);
}

/**
 * swapToReduce() debe funcionar
 * correctamente cuando hay tapas mezcladas en el stack.
 * Si sugiere un swap, aplicarlo debe reducir la altura.
 */
@Test
public void accordingBAShould_SwapToReduceWorksWithLidsInStack() {
    tower.pushCup(1);
    tower.pushLid(1);
    tower.pushCup(4);
    int heightBefore = tower.height();
    String[][] swap = tower.swapToReduce();
    assertTrue("swapToReduce con tapas debe completarse sin error", tower.ok());
    if (swap != null) {
        tower.swap(swap[0], swap[1]);
        assertTrue("El swap sugerido debe reducir la altura",
                   tower.height() < heightBefore);
    }
}

/**
 * swapToReduce() NO debe modificar
 * el stack — es solo una consulta. El primer y último
 * elemento deben ser los mismos antes y después.
 */
@Test
public void accordingBAShould_SwapToReduceDoesNotModifyStack() {
    tower.pushCup(2);
    tower.pushCup(4);
    tower.pushCup(1);
    String[][] before = tower.stackingItems();
    tower.swapToReduce();
    String[][] after = tower.stackingItems();
    assertEquals("swapToReduce no debe cambiar el primer elemento",
                 before[0][1], after[0][1]);
    assertEquals("swapToReduce no debe cambiar el último elemento",
                 before[before.length - 1][1], after[after.length - 1][1]);
                }
// orderTower y reverseTower con stacks mezclados
/**
 * reverseTower() con tazas y tapas
 * mezcladas debe invertir TODO el stack, no solo las tazas.
 * Stack [cup4, lid4, cup2] debe quedar [cup2, lid4, cup4].
 */
@Test
public void accordingBAShould_ReverseMixedStackCompletely() {
    tower.pushCup(4);
    tower.pushLid(4);
    tower.pushCup(2);
    tower.reverseTower();
    String[][] items = tower.stackingItems();
    assertEquals("cup2 debe estar primera", "2", items[0][1]);
    assertEquals("cup4 debe estar última", "4", items[2][1]);
}

/**
 * orderTower() debe ordenar tazas y tapas
 * juntas por índice descendente. El primer objeto del stack
 * debe tener índice mayor o igual al segundo.
 */
@Test
public void accordingBAShould_OrderMixedStackByIndexDescending() {
    tower.pushCup(1);
    tower.pushLid(4);
    tower.pushCup(4);
    tower.pushCup(2);
    tower.orderTower();
    String[][] items = tower.stackingItems();
    int first  = Integer.parseInt(items[0][1]);
    int second = Integer.parseInt(items[1][1]);
    assertTrue("El primer objeto debe tener índice >= al segundo", first >= second);
    }
}


