import shapes.*;
import java.util.ArrayList;

/**
 * Tower - Controlador principal del simulador de torre de tazas.
 * 
 * Maneja una colección de tazas (Cup) y tapas (Lid) apiladas.
 * 
 * REGLA ICPC DE ANIDAMIENTO:
 * Una taza más pequeña cae DENTRO de la primera taza más grande
 * que aparece antes de ella en el stack. Su base queda a +1 cm
 * sobre la base de esa taza contenedora.
 * 
 * Ejemplo: stack = [cup4, cup2, cup3, cup1]
 *   - cup4: base en 0 cm, top en 8 cm
 *   - cup2: base en 1 cm (dentro de cup4), top en 3 cm
 *   - cup3: base en 1 cm (dentro de cup4), top en 5 cm
 *   - cup1: base en 2 cm (dentro de cup3), top en 3 cm
 *   Altura total = 8 cm
 *
 * ════════════════════════════════════════════════
 * CICLO 1: Tower(width,maxHeight), push/pop/remove
 *          cup y lid, order, reverse, height,
 *          lidedCups, stackingItems, makeVisible,
 *          makeInvisible, ok, exit
 * 
 * CICLO 2: Tower(cups), swap, cover, swapToReduce
 * ════════════════════════════════════════════════
 *
 * @author Mabel Bernal, Jeronimo Avila
 * @version Ciclo 2
 */
public class Tower {

    // ── Atributos ─────────────────────────────────────────────

    private int width;      // Ancho lógico de la torre (parámetro de configuración)
    private int maxHeight;  // Altura máxima permitida en cm

    // El stack guarda TODOS los objetos en el orden en que fueron agregados.
    // Puede contener tanto Cup como Lid mezclados.
    private ArrayList<Object> stack;

    // Listas separadas para acceder rápido solo a tazas o solo a tapas
    private ArrayList<Cup> cups;
    private ArrayList<Lid> lids;

    private boolean isVisible;        // Si la torre está siendo mostrada
    private boolean lastOperationOk;  // Resultado de la última operación

    // Marcas de la escala visual (rayitas al lado izquierdo del canvas)
    private ArrayList<Rectangle> scale;

    // ── Constantes de posición en pantalla ───────────────────
    // X_CENTER: columna central donde se centran todas las tazas
    // Y_BASE: línea del suelo desde donde crecen las tazas hacia arriba
    private static final int X_CENTER = 150;
    private static final int Y_BASE   = 200;

    // Colores asignados automáticamente según el índice de la taza
    // (índice - 1) % 8 para que se repitan si hay más de 8 tazas
    private static final String[] COLORS = {
        "red", "blue", "green", "yellow",
        "magenta", "black", "white", "orange"
    };

    // ══════════════════════════════════════════════════════════
    // CICLO 1 - Constructor original
    // ══════════════════════════════════════════════════════════

    /**
     * Crea una torre vacía con los parámetros dados.
     *
     * @param width     ancho lógico de la torre
     * @param maxHeight altura máxima permitida en cm
     */
    public Tower(int width, int maxHeight) {
        this.width           = width;
        this.maxHeight       = maxHeight;
        this.isVisible       = false;
        this.cups            = new ArrayList<Cup>();
        this.lids            = new ArrayList<Lid>();
        this.stack           = new ArrayList<Object>();
        this.lastOperationOk = true;
        this.scale           = new ArrayList<Rectangle>();
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 2 - Constructor nuevo (Requisito 10)
    // ══════════════════════════════════════════════════════════

    /**
     * CICLO 2 - Crea una torre ya con tazas de 1 a cups.
     * No incluye tapas (según indicación del enunciado).
     * 
     * Ejemplo: Tower(4) crea las tazas 1, 2, 3 y 4.
     * Las tazas tienen alturas 1, 2, 4 y 7 cm respectivamente.
     *
     * @param cups número de tazas a crear (por ejemplo 4)
     */
    public Tower(int cups) {
        // Llamamos al constructor original con valores proporcionales
        this(cups * 2, cups * 8);
        // Agregamos las tazas de 1 a cups
        for (int i = cups; i >= 1; i--) {
            pushCup(i);
        }
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 1 - Visibilidad
    // ══════════════════════════════════════════════════════════

    /**
     * Muestra la torre completa en el canvas de BlueJ.
     * Primero recalcula posiciones, luego hace visible cada objeto.
     */
    public void makeVisible() {
        isVisible = true;
        repositionAllItems(); // calcular posiciones antes de mostrar
        for (Cup cup : cups) cup.makeVisible();
        for (Lid lid : lids) lid.makeVisible();
        drawScale(); // dibujar la regla de centímetros
    }

    /**
     * Oculta toda la torre del canvas.
     */
    public void makeInvisible() {
        isVisible = false;
        for (Cup cup : cups)      cup.makeInvisible();
        for (Lid lid : lids)      lid.makeInvisible();
        for (Rectangle r : scale) r.makeInvisible();
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 1 - Manejo de tazas (push, pop, remove)
    // ══════════════════════════════════════════════════════════

    /**
     * Agrega la taza número i al stack de la torre.
     * Si i < 1, la operación falla (ok() retorna false).
     *
     * @param i índice de la taza a agregar (>= 1)
     */
    public void pushCup(int i) {
        if (i < 1) {
            lastOperationOk = false;
            showError("El índice de taza debe ser >= 1");
            return;
        }
        // Asignar color automáticamente según el índice
        String color = COLORS[(i - 1) % COLORS.length];
        Cup newCup = new Cup(i, color);
        cups.add(newCup);   // agregar a la lista de tazas
        stack.add(newCup);  // agregar al stack general
        repositionAllItems();
        if (isVisible) newCup.makeVisible(); // mostrar si la torre está visible
        lastOperationOk = true;
    }

    /**
     * Elimina la última taza que fue agregada al stack.
     * Si no hay tazas, la operación falla.
     */
    public void popCup() {
        if (cups.isEmpty()) {
            lastOperationOk = false;
            showError("No hay tazas en la torre");
            return;
        }
        // Remover la última taza de ambas listas
        Cup removed = cups.remove(cups.size() - 1);
        stack.remove(removed);
        removed.makeInvisible();
        repositionAllItems();
        lastOperationOk = true;
    }

    /**
     * Elimina la taza en la posición i de la lista de tazas.
     * i es 0-based (0 = primera taza en la lista).
     *
     * @param i posición en la lista de tazas (0-based)
     */
    public void removeCup(int i) {
        if (i < 0 || i >= cups.size()) {
            lastOperationOk = false;
            showError("Índice inválido: debe ser entre 0 y " + (cups.size() - 1));
            return;
        }
        Cup removed = cups.remove(i);
        stack.remove(removed);
        removed.makeInvisible();
        repositionAllItems();
        lastOperationOk = true;
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 1 - Manejo de tapas (push, pop, remove)
    // ══════════════════════════════════════════════════════════

    /**
     * Agrega la tapa de la taza i al stack de la torre.
     *
     * @param i índice de la taza cuya tapa se agrega (>= 1)
     */
    public void pushLid(int i) {
        if (i < 1) {
            lastOperationOk = false;
            showError("El índice debe ser >= 1");
            return;
        }
        String color = COLORS[(i - 1) % COLORS.length];
        Lid newLid = new Lid(i, color);
        lids.add(newLid);
        stack.add(newLid);
        repositionAllItems();
        if (isVisible) newLid.makeVisible();
        lastOperationOk = true;
    }

    /**
     * Elimina la última tapa que fue agregada al stack.
     */
    public void popLid() {
        if (lids.isEmpty()) {
            lastOperationOk = false;
            showError("No hay tapas en la torre");
            return;
        }
        Lid removed = lids.remove(lids.size() - 1);
        stack.remove(removed);
        removed.makeInvisible();
        repositionAllItems();
        lastOperationOk = true;
    }

    /**
     * Elimina la tapa en la posición i de la lista de tapas.
     *
     * @param i posición en la lista de tapas (0-based)
     */
    public void removeLid(int i) {
        if (i < 0 || i >= lids.size()) {
            lastOperationOk = false;
            showError("Índice inválido: debe ser entre 0 y " + (lids.size() - 1));
            return;
        }
        Lid removed = lids.remove(i);
        stack.remove(removed);
        removed.makeInvisible();
        repositionAllItems();
        lastOperationOk = true;
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 1 - Reorganizar (order, reverse)
    // ══════════════════════════════════════════════════════════

    /**
     * Ordena las tazas de mayor a menor altura (mayor índice primero).
     * También ordena las tapas de mayor a menor índice.
     * Luego reconstruye el stack en el nuevo orden.
     * 
     * ciclo 2
     * A diferencia de la versión del Ciclo 1, este método opera
     * directamente sobre el stack completo en lugar de ordenar
     * las listas de tazas y tapas por separado. Esto preserva
     * el orden mezclado correcto entre tazas y tapas.
     */
    public void orderTower() {
        // Ordenar tazas
        stack.sort((a, b) -> {
            int ia;
            int ib;
            if (a instanceof Cup){
                ia = ((Cup) a).getIndex();
            } else{
                ia = ((Lid) a).getCupIndex();            
            }
            if (b instanceof Cup){
                ib = ((Cup) b).getIndex();            
            } else {
                ib = ((Lid) b).getCupIndex(); 
            
            }
            return ib - ia;
        });
        cups.clear();
        lids.clear();
        for (Object obj : stack) {
            if (obj instanceof Cup) cups.add((Cup) obj);
            
            else lids.add((Lid) obj);            
        }
        repositionAllItems();
        lastOperationOk = true;
        }
    

    /**
     * Invierte el orden actual de tazas y tapas en el stack.
     * 
     * ciclo 2
     * A diferencia de la versión del Ciclo 1, opera directamente
     * sobre el stack completo para preservar el orden mezclado.
     */
    public void reverseTower() {
        java.util.Collections.reverse(stack);
        cups.clear();
        lids.clear();
        for (Object obj : stack){
            if (obj instanceof Cup) cups.add((Cup) obj);
            else lids.add ((Lid) obj);
        }
        repositionAllItems();
        lastOperationOk = true;
    }

    // ══════════════════════════════════════════════════════════
    // CICLO 2 - swap (Requisito 11)
    // ══════════════════════════════════════════════════════════

    /**
     * CICLO 2 - Intercambia la posición de dos objetos en el stack.
     * 
     * Los objetos se identifican con un arreglo de dos strings:
     *   {"cup", "4"} = la taza número 4
     *   {"lid", "3"} = la tapa de la taza 3
     * 
     * Si alguno de los objetos no existe en la torre, ok() retorna false.
     *
     * @param o1 descriptor del primer objeto  (ej: {"cup","4"})
     * @param o2 descriptor del segundo objeto (ej: {"lid","4"})
     */
    public void swap(String[] o1, String[] o2) {
        // Buscar la posición de cada objeto en el stack
        int idx1 = findInStack(o1);
        int idx2 = findInStack(o2);

        // Si alguno no existe, reportar error
        if (idx1 == -1 || idx2 == -1) {
            lastOperationOk = false;
            showError("Objeto no encontrado en la torre");
            return;
        }

        // Intercambiar usando variable temporal (patrón clásico de swap)
        Object temp = stack.get(idx1);
        stack.set(idx1, stack.get(idx2));
        stack.set(idx2, temp);

        // Reconstruir las listas cups y lids en el nuevo orden del stack
        cups.clear();
        lids.clear();
        for (Object obj : stack) {
            if (obj instanceof Cup) cups.add((Cup) obj);
            else                   lids.add((Lid) obj);
        }

        repositionAllItems(); // actualizar posiciones visuales
        lastOperationOk = true;
    }

    /**
     * Busca un objeto en el stack por su descriptor.
     * Recorre el stack y compara tipo e índice.
     *
     * @param descriptor {"cup","4"} o {"lid","3"}
     * @return posición en el stack (0-based), o -1 si no existe
     */
    private int findInStack(String[] descriptor) {
        String type   = descriptor[0].toLowerCase(); // "cup" o "lid"
        int    number = Integer.parseInt(descriptor[1]); // índice numérico

        for (int i = 0; i < stack.size(); i++) {
            Object obj = stack.get(i);
            if (type.equals("cup") && obj instanceof Cup) {
                if (((Cup) obj).getIndex() == number) return i;
            } else if (type.equals("lid") && obj instanceof Lid) {
                if (((Lid) obj).getCupIndex() == number) return i;
            }
        }
        return -1; // no encontrado
    }
    // CICLO 2 - cover (Requisito 12)
    /**
     * CICLO 2 - Tapa visualmente todas las tazas que tienen
     * su tapa disponible en la torre.
     * 
     * Recorre cada taza y busca si hay una tapa con el mismo índice
     * en la lista de lids. Si la encuentra, marca la taza como tapada
     * (cambia su color a negro para que luzca diferente).
     * 
     * Requisito de usabilidad: "las tazas tapadas deben lucir diferentes".
     */
    public void cover() {
        for (Cup cup : cups) {
            boolean hasLid = false;
            // Buscar si existe una tapa para esta taza
            for (Lid lid : lids) {
                if (lid.getCupIndex() == cup.getIndex()) {
                    hasLid = true;
                    break; // encontramos la tapa, no necesitamos seguir buscando
                }
            }
            // Marcar la taza según si tiene tapa o no
            cup.setCovered(hasLid);
        }
        lastOperationOk = true;
    }
    public boolean isCupCovered(int cupIndex){
        for (Cup cup : cups){
            if (cup.getIndex() == cupIndex) {
                return cup.isCovered();
            }
        }
        return false;
    }
    // CICLO 2 - swapToReduce (Requisito 13)
    /**
     * CICLO 2 - Consulta qué intercambio de dos objetos reduciría
     * la altura de la torre.
     * 
     * IMPORTANTE: Este método NO modifica la torre. Solo simula
     * intercambios temporalmente para encontrar el mejor.
     * 
     * Algoritmo: prueba todos los pares posibles (i, j) del stack,
     * simula el intercambio, mide la altura resultante, y guarda
     * el par que produjo la menor altura.
     * 
     * @return arreglo con los dos descriptores a intercambiar,
     *         por ejemplo {{"cup","4"},{"cup","2"}}.
     *         Retorna null si ningún intercambio reduce la altura.
     */
    public String[][] swapToReduce() {
        int currentHeight   = computeHeightCm(); // altura actual
        int bestHeight      = currentHeight;     // la mejor altura encontrada
        String[][] bestSwap = null;              // el mejor intercambio encontrado

        // Probar todos los pares posibles (combinaciones de 2)
        for (int i = 0; i < stack.size(); i++) {
            for (int j = i + 1; j < stack.size(); j++) {

                // Simular el intercambio temporalmente
                Object tmp = stack.get(i);
                stack.set(i, stack.get(j));
                stack.set(j, tmp);

                // Medir la altura con este intercambio
                int newHeight = computeHeightCm();
                if (newHeight < bestHeight) {
                    bestHeight = newHeight;
                    // Guardar los descriptores de los objetos intercambiados
                    bestSwap = new String[][] {
                        descriptorOf(stack.get(i)),
                        descriptorOf(stack.get(j))
                    };
                }

                // Revertir el intercambio (dejar el stack como estaba)
                stack.set(j, stack.get(i));
                stack.set(i, tmp);
            }
        }

        lastOperationOk = true;
        return bestSwap; // null si ningún intercambio ayuda
    }
    /**
     * Crea el descriptor {"cup","4"} o {"lid","3"} de un objeto del stack.
     *
     * @param obj objeto del stack (Cup o Lid)
     * @return arreglo con tipo e índice como strings
     */
    private String[] descriptorOf(Object obj) {
        if (obj instanceof Cup) {
            return new String[]{"cup", String.valueOf(((Cup) obj).getIndex())};
        } else {
            return new String[]{"lid", String.valueOf(((Lid) obj).getCupIndex())};
        }
    }
    // CICLO 1 - Consultas
    /**
     * Retorna la altura total de la torre en cm.
     * Delega el cálculo a computeHeightCm().
     */
    public int height() { return computeHeightCm(); }

    /**
     * Retorna los índices de las tazas que tienen tapa en la torre.
     * Por ejemplo: si hay tapas para las tazas 2 y 4, retorna [2, 4].
     *
     * @return arreglo de índices (puede estar vacío si no hay tapas)
     */
    public int[] lidedCups() {
        int[] result = new int[lids.size()];
        for (int i = 0; i < lids.size(); i++) {
            result[i] = lids.get(i).getCupIndex();
        }
        return result;
    }

    /**
     * Retorna todos los objetos del stack con su tipo e índice.
     * Cada fila tiene [tipo, índice]:
     *   items[0] = {"cup", "4"}
     *   items[1] = {"cup", "2"}
     *   items[2] = {"lid", "4"}
     *
     * @return matriz de strings con el estado del stack
     */
    public String[][] stackingItems() {
        String[][] items = new String[stack.size()][2];
        for (int i = 0; i < stack.size(); i++) {
            Object obj = stack.get(i);
            if (obj instanceof Cup) {
                items[i][0] = "cup";
                items[i][1] = String.valueOf(((Cup) obj).getIndex());
            } else {
                items[i][0] = "lid";
                items[i][1] = String.valueOf(((Lid) obj).getCupIndex());
            }
        }
        return items;
    }

    /**
     * Retorna true si la última operación fue exitosa, false si hubo error.
     */
    public boolean ok() { return lastOperationOk; }

    /**
     * Limpia toda la torre y cierra la visualización.
     */
    public void exit() {
        makeInvisible();
        cups.clear();
        lids.clear();
        stack.clear();
        lastOperationOk = true;
    }
    // CICLO 1 - Posicionamiento visual (métodos privados)
    /**
     * Calcula la posición en píxeles de cada objeto del stack
     * y llama a moveTo() para ubicarlos en el canvas.
     * 
     * Lógica ICPC:
     * - Una taza cae DENTRO de la primera taza más grande que la precede.
     * - Su base queda a baseCm[contenedora] + 1 cm.
     * - Una tapa va encima de su taza: su base = top de la taza.
     */
    private void repositionAllItems() {
        int n = stack.size();
        if (n == 0) return;

        // topCm[i]  = altura (en cm) donde termina el objeto i
        // baseCm[i] = altura (en cm) donde empieza el objeto i
        int[] topCm  = new int[n];
        int[] baseCm = new int[n];

        // Calcular las alturas lógicas en cm para cada objeto
        for (int i = 0; i < n; i++) {
            Object obj = stack.get(i);

            if (obj instanceof Cup) {
                Cup cup = (Cup) obj;
                int supportTopCm = 0; // altura del soporte (por defecto, el suelo = 0)

                // Buscar la primera taza más grande que la soporte
                for (int j = i - 1; j >= 0; j--) {
                    if (stack.get(j) instanceof Cup) {
                        Cup prev = (Cup) stack.get(j);
                        if (prev.getIndex() > cup.getIndex()) {
                            // Esta taza más grande la soporta: su base va 1 cm más arriba
                            supportTopCm = baseCm[j] + 1;
                            break;
                        }
                    }
                }
                baseCm[i] = supportTopCm;
                topCm[i]  = supportTopCm + cup.getHeight();

            } else {
                // Es una tapa: va encima de su taza
                Lid lid     = (Lid) obj;
                int lidBase = 0;

                // Buscar la taza o tapa más reciente con el mismo índice
                for (int j = i - 1; j >= 0; j--) {
                    if (stack.get(j) instanceof Cup) {
                        Cup prev = (Cup) stack.get(j);
                        if (prev.getIndex() == lid.getCupIndex()) {
                            lidBase = topCm[j]; break;
                        }
                    } else {
                        Lid prevLid = (Lid) stack.get(j);
                        if (prevLid.getCupIndex() == lid.getCupIndex()) {
                            lidBase = topCm[j]; break;
                        }
                    }
                }
                baseCm[i] = lidBase;
                topCm[i]  = lidBase + 1; // la tapa mide 1 cm
            }
        }

        // Convertir las alturas en cm a píxeles y llamar a moveTo()
        for (int i = 0; i < n; i++) {
            Object obj = stack.get(i);
            if (obj instanceof Cup) {
                Cup cup = (Cup) obj;
                // Y crece hacia abajo en pantalla, así que restamos para ir hacia arriba
                int yTopPx  = Y_BASE - topCm[i] * Cup.PX_PER_CM;
                int xLeftPx = X_CENTER - cup.getPixelWidth() / 2; // centrar horizontalmente
                cup.moveTo(xLeftPx, yTopPx);
            } else {
                Lid lid     = (Lid) obj;
                int yTopPx  = Y_BASE - topCm[i] * Cup.PX_PER_CM;
                int xLeftPx = X_CENTER - lid.getPixelWidth() / 2;
                lid.moveTo(xLeftPx, yTopPx);
            }
        }
    }
    /**
     * Calcula la altura total de la torre en cm.
     * Usa la misma lógica que repositionAllItems() pero
     * solo retorna el topCm máximo encontrado.
     *
     * @return altura total en cm
     */
    private int computeHeightCm() {
        int n = stack.size();
        if (n == 0) return 0;

        int[] topCm  = new int[n];
        int[] baseCm = new int[n];
        int maxTop   = 0;

        for (int i = 0; i < n; i++) {
            Object obj = stack.get(i);
            if (obj instanceof Cup) {
                Cup cup = (Cup) obj;
                int supportTopCm = 0;
                for (int j = i - 1; j >= 0; j--) {
                    if (stack.get(j) instanceof Cup) {
                        Cup prev = (Cup) stack.get(j);
                        if (prev.getIndex() > cup.getIndex()) {
                            supportTopCm = baseCm[j] + 1;
                            break;
                        }
                    }
                }
                baseCm[i] = supportTopCm;
                topCm[i]  = supportTopCm + cup.getHeight();
            } else {
                Lid lid     = (Lid) obj;
                int lidBase = 0;
                for (int j = i - 1; j >= 0; j--) {
                    if (stack.get(j) instanceof Cup) {
                        Cup prev = (Cup) stack.get(j);
                        if (prev.getIndex() == lid.getCupIndex()) { lidBase = topCm[j]; break; }
                    } else {
                        Lid prevLid = (Lid) stack.get(j);
                        if (prevLid.getCupIndex() == lid.getCupIndex()) { lidBase = topCm[j]; break; }
                    }
                }
                baseCm[i] = lidBase;
                topCm[i]  = lidBase + 1;
            }
            // Guardar el mayor topCm encontrado
            if (topCm[i] > maxTop) maxTop = topCm[i];
        }
        return maxTop;
    }
    /**
     * Reconstruye el stack a partir de las listas cups y lids.
     * Se usa después de ordenar o invertir para que el stack
     * refleje el nuevo orden.
     */
    private void rebuildStack() {
        stack.clear();
        stack.addAll(cups); // primero todas las tazas
        stack.addAll(lids); // luego todas las tapas
    }
    /**
     * Dibuja las marcas de la escala (regla) al lado izquierdo del canvas.
     * Cada 5 cm la marca es más larga para facilitar la lectura.
     */
    private void drawScale() {
        // Borrar escala anterior
        for (Rectangle r : scale) r.makeInvisible();
        scale.clear();
        if (!isVisible) return;

        int maxCm  = Math.min(maxHeight, 20);
        int xScale = 30; // posición horizontal de la escala

        for (int cm = 0; cm <= maxCm; cm++) {
            Rectangle mark = new Rectangle();
            mark.changeColor("black");
            // Marca más larga cada 5 cm
            mark.changeSize(2, (cm % 5 == 0) ? 12 : 6);
            // Ajustar por el offset inicial de shapes (x=70, y=15)
            mark.moveHorizontal(xScale - 70);
            mark.moveVertical((Y_BASE - cm * Cup.PX_PER_CM) - 15);
            mark.makeVisible();
            scale.add(mark);
        }
    }
    /**
     * Muestra un mensaje de error en pantalla (si es visible)
     * y también lo imprime en la consola.
     */
    private void showError(String msg) {
        if (isVisible) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error: " + msg);
        }
        System.out.println("Error: " + msg);
    }
}
