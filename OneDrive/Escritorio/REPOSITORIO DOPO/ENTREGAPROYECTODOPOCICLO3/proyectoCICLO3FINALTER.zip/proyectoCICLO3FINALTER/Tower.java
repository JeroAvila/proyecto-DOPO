import shapes.*;
import java.util.ArrayList;
/**
 * Modela la torre del simulador Stacking Cups 
 * @author Avila - Bernal
 * @version 3 - Ciclo 2
 */
public class Tower {
    /**
     * ATRIBUTOS
     */  
    // Coordenada Y de la base de la torre en el canvas. 
    private static final int CANVAS_BASE_Y   = 520;
    // Coordenada X del centro horizontal del canvas. 
    private static final int CANVAS_CENTER_X = 250;  
    //Color que identifica visualmente las tapas tapadas   
    private static final String COVERED_COLOR = "cyan";
    // Paleta de colores para asignar a ítems según su número. 
    private static final String[] PALETTE = {
        "blue", "green", "red", "yellow", "orange", "magenta", "black", "white"
    };   
     //Lista ordenada de ítems.    
    private ArrayList<StackableItem> items;
    // Ancho del canvas (referencia visual)
    private int canvasWidth;
    // Altura máxima permitida en cm 
    private int maxHeightCm;
    // True si la torre está visible en el canvas
    private boolean isDisplayed;
    // Resultado de la última operación pública
    private boolean lastOpOk;
    // Marcas de la regla lateral. 
    private ArrayList<Rectangle> scaleMarks;   
    // Constructores   
    /**
     * Constructor base: .
     * torre vacía con dimensiones dadas
     * @param canvasWidth  ancho del canvas en px
     * @param maxHeightCm  altura máxima en cm
     */
    public Tower(int canvasWidth, int maxHeightCm) {
        this.canvasWidth  = canvasWidth;
        this.maxHeightCm  = maxHeightCm;
        this.isDisplayed  = false;
        this.lastOpOk     = true;
        this.items        = new ArrayList<StackableItem>();
        this.scaleMarks   = new ArrayList<Rectangle>();
    }
    /**
     * Crea una torre con N tazas numeradas de 1 a N.
     * La taza N (más grande) queda en la base,
     * la taza 1 (más pequeña) en la cima.
     * NO se crean tapas  ciclo 2
     * Tower(4) crea [Cup4, Cup3, Cup2, Cup1] de base a cima.
     *
     * @param numberOfCups cantidad de tazas (>= 1)
     */
    public Tower(int numberOfCups) {
        // ciclo 3 quitar fail y añadir throws
        this(500, 300);
        if (numberOfCups < 1) { lastOpOk = false; return; }
        // Agregar de mayor a menor
        for (int i = numberOfCups; i >= 1; i--) {
            items.add(new Cup(i, colorForNumber(i)));
        }
        lastOpOk = true;
    }
    // Visibilidad
    /**
     * Hace visible la torre.
     * Reposiciona todos los ítems
     * dibuja la regla.
     */
    public void makeVisible() {
        if (isDisplayed) return;
        isDisplayed = true;
        repositionAll();
        for (StackableItem item : items) item.makeVisible();
        buildScaleRule();
    }
    /**
     * Hace invisible la torre.
     * Oculta todos los ítems y la regla lateral.
     */
    public void makeInvisible() {
        if (!isDisplayed) return;
        for (StackableItem item : items) item.makeInvisible();
        hideScaleRule();
        isDisplayed = false;
    }
    // Gestión de tazas
    /**
     * Agrega una nueva taza a la cima de la torre.
     *
     * @param cupNumber número de la taza (>= 1)
     */
    public void pushCup(int cupNumber) throws TowerException {
        //ciclo 3 se cambia el fail
        //Ahora lanzan TowerException y declaran throws en la firma
        if (cupNumber < 1) { 
        lastOpOk = false;
        throw new TowerException(TowerException.INVALID_NUMBER,
            "El numero de taza debe ser >= 1, recibido: " +cupNumber);
    }
        StackableItem newCup = new Cup(cupNumber, colorForNumber(cupNumber));
        items.add(newCup);
        if (isDisplayed) { repositionAll(); newCup.makeVisible(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Quita la última taza de la torre
     */
    public void popCup() throws TowerException {
        //ciclo 3 los mismos cambios que pushCup 
        int idx = lastIndexOfType("cup");
        if (idx < 0) {
            lastOpOk = false;
            throw new TowerException(TowerException.NO_CUPS,
                "No hay tazas en la torre");
        }
        items.remove(idx).makeInvisible();
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Elimina la taza en la posición lógica indicada
     * @param position posición entre las tazas
     */
    public void removeCup(int position) throws TowerException {
        //  ciclo 3 se quita fail y se implementa TowerException
        int real = realIndexOfNthOfType("cup", position);
        if (real < 0) {
            lastOpOk = false;
            throw new TowerException(TowerException.INVALID_CUP_POSITION,
                "Posicion de taza invalida " + position);
        }
        items.remove(real).makeInvisible();
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    // Gestión de tapas
    /**
     * Agrega una nueva tapa a la CIMA de la torre.
     *
     * @param cupNumber número de la taza propietaria (>= 1)
     */
    public void pushLid(int cupNumber) throws TowerException{
        //ciclo 3 se quita fail y se implement TowerException
        if (cupNumber < 1) {
            lastOpOk = false;
            throw new TowerException(TowerException.INVALID_NUMBER,
                "El numero de tapa debe ser >=1, recibido: " + cupNumber);
        }
        StackableItem newLid = new Lid(cupNumber, colorForNumber(cupNumber));
        items.add(newLid);
        if (isDisplayed) { repositionAll(); newLid.makeVisible(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Quita la última tapa de la torre.
     * Si su taza estaba marcada como tapada, la desmarca.
     */
    public void popLid() throws TowerException {
        // ciclo 3 se quita fail y se agrega TowerException
        int idx = lastIndexOfType("lid");
        if (idx < 0) {
            lastOpOk = false;
            throw new TowerException(TowerException.NO_LIDS,
                "No hay tapas en la torre");
        }
        StackableItem removed = items.remove(idx);
        removed.makeInvisible();
        uncoverMatchingCup(removed.getItemNumber());
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Elimina la tapa en la posición lógica indicada (0 = primera tapa desde la base).
     *
     * @param position posición entre las tapas
     */
    public void removeLid(int position) throws TowerException {
        //se quita el fail y se agrega TowerException
        int real = realIndexOfNthOfType("lid", position);
        if (real < 0) {
            lastOpOk = false;
            throw new TowerException(TowerException.INVALID_LID_POSITION,
                "Posicion de tapa invalida: " + position);
        }
        StackableItem removed = items.remove(real);
        removed.makeInvisible();
        uncoverMatchingCup(removed.getItemNumber());
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    // Reorganización
    /**
     * Ordena las tazas de mayor a menor altura lógica (taza más grande en la base).
     * Cada tapa queda inmediatamente después de su taza.
     * Las tapas sin taza en la torre van al final.
     */
    public void orderTower() {
        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();
        sortItemsByHeightDescending();
        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
    /**
     * Invierte el orden de todos los ítems.
     * Corrige tapas que queden antes de su taza tras la inversión
     * (una tapa no puede estar por debajo de su taza en la lista).
     */
    public void reverseTower() {
        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();
        java.util.Collections.reverse(items);
        // Post-corrección: mover tapas que quedaron antes que su taza
        for (int i = 0; i < items.size(); i++) {
            if (!items.get(i).isContainer()) continue; // solo tazas (Cup)
            int cupNumber = items.get(i).getItemNumber();
            for (int j = 0; j < i; j++) {
                if (!items.get(j).isContainer() &&
                    items.get(j).getItemNumber() == cupNumber) {
                    StackableItem misplaced = items.remove(j);
                    items.add(i, misplaced);
                    break;
                }
            }
        }
        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
     /**
      * Intercambia las posiciones de dos ítems en la torre.
      * Cada ítem se identifica por su tipo ("cup" o "lid") y su número.
      * 
      * @param type1 tipo del primer ítem ("cup" o "lid")
      * @param n1 número del primer ítem
      * @param type2 tipo del segundo ítem ("cup" o "lid")
      * @param n2 número del segundo ítem
      * 
      */       

    public void swap(String type1, int n1, String type2, int n2) throws TowerException {
    // se agrega TowerException
    String[] id1 = new String[] {type1, String.valueOf(n1)};
    String[] id2 = new String[] {type2, String.valueOf(n2)};
    swap(id1, id2);
    }
    public void swap(String[] id1, String[] id2) throws TowerException {
        //ciclo 3 se quita fail y se agrega TowerException
        int i1 = findItemIndex(id1);
        int i2 = findItemIndex(id2);
        if (i1 < 0 || i2 < 0) {
            lastOpOk = false;
            throw new TowerException(TowerException.ITEM_NOT_FOUND,
                "Ítem no encontrado para swap");
        }

        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();

        StackableItem tmp = items.get(i1);
        items.set(i1, items.get(i2));
        items.set(i2, tmp);

        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
    /**
     * Tapa todas las tazas que tienen su tapa en la torre.
     * Las tazas tapadas cambian a COVERED_COLOR.
     * Las tazas sin tapa recuperan su color original.
     *  Ciclo 2 actualiza el color 
     * 
     */
    public void cover() {
        // Desmarcar todas las tazas
        for (StackableItem item : items) {
            item.notifyCover(false); // Cup lo atiende; Lid lo ignora
        }
        // Marcar las tazas que SÍ tienen su tapa en la torre
        for (StackableItem lid : items) {
            if (!lid.isContainer() && "lid".equals(lid.getItemType())) {
                StackableItem matchingCup = findItemByTypeAndNumber("cup", lid.getItemNumber());
                if (matchingCup != null) {
                    matchingCup.notifyCover(true); 
                }
            }
        }
        lastOpOk = true;
    }
    // Consultas
    /**
     * Calcula la altura total de la torre en cm considerando el anidamiento.
     *
     * @return altura total en cm
     */
    public int height() {
        // Pila de anchos interiores de contenedores activos
        java.util.Stack<Integer> containerInteriors = new java.util.Stack<Integer>();
        int total = 0;
        for (StackableItem item : items) {
            int w = item.getWidthPixels();

            // Desapilar contenedores donde el ítem no cabe
            while (!containerInteriors.isEmpty() && w >= containerInteriors.peek()) {
                containerInteriors.pop();
            }
            if (containerInteriors.isEmpty()) {
                // No cabe en ningún contenedor: va encima y SUMA altura
                total += item.getHeightCm();
                if (item.isContainer()) {
                    containerInteriors.push(item.getInteriorWidth());
                }
            } else {
                // Cabe dentro de un contenedor: NO suma altura
                if (item.isContainer()) {
                    containerInteriors.push(item.getInteriorWidth());
                }
            }
        }
        return total;
    }
    /**
     * Devuelve los números de las tazas que tienen su tapa en la torre.
     *
     * @return arreglo de números de tazas tapadas (puede ser vacío)
     */
    public int[] lidedCups() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (StackableItem item : items) {
            if ("lid".equals(item.getItemType())) {
                int cupNum = item.getItemNumber();
                if (findItemByTypeAndNumber("cup", cupNum) != null) {
                    result.add(cupNum);
                }
            }
        }
        int[] out = new int[result.size()];
        for (int i = 0; i < out.length; i++) out[i] = result.get(i);
        return out;
    }
    /**
     * Devuelve todos los ítems como matriz de strings.
     * Formato: {{tipo, número}, ...}. Índice 0 = base.
     *
     * @return String[n][2] con "cup"/"lid" y el número de cada ítem
     */
    public String[][] stackingItems() {
        String[][] result = new String[items.size()][2];
        for (int i = 0; i < items.size(); i++) {
            result[i][0] = items.get(i).getItemType();
            result[i][1] = String.valueOf(items.get(i).getItemNumber());
        }
        return result;
    }

    /**
     * Busca el primer intercambio entre dos ítems que reduzca la altura.
     * Prueba todos los pares (i, j) con i < j.
     * @return identificadores de los dos ítems a intercambiar, o null si no hay mejora
     */
    public String[][] swapToReduce() {
        int currentHeight = height();
        for (int i = 0; i < items.size() - 1; i++) {
            for (int j = i + 1; j < items.size(); j++) {
                // Simular swap
                StackableItem tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);

                int newHeight = height();

                // Deshacer swap
                tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);

                if (newHeight < currentHeight) {
                    lastOpOk = true;
                    return new String[][]{
                        toIdentifier(items.get(i)),
                        toIdentifier(items.get(j))
                    };
                }
            }
        }
        lastOpOk = true;
        return null;
    }
    /**
     * Cierra el simulador: oculta la torre y limpia todos los ítems.
     */
    public void exit() {
        makeInvisible();
        items.clear();
        lastOpOk = true;
    }
    /**
     * CICLO 3 — Voltea la torre.
     * 
     * Simula que la torre se inclina y cae
     * todos los ítems se ocultan y la torre queda vacía.
     *  Si la torre ya estaba vacía, lanza TowerException.
     * 
     */
    public void tilt() throws TowerException {
        if (items.isEmpty()) {
            lastOpOk = false;
            throw new TowerException(TowerException.EMPTY_TOWER,
                "No se puede inclinar una torre vacia");
        }
        makeInvisible();
        items.clear();
        lastOpOk = true;
     }
    
    /**
     * @return true si la última operación fue exitosa; false si falló.
     */
    public boolean ok() {
        return lastOpOk;
    }
    // Posicionamiento visual (privado)
    /**
     * Reposiciona todos los ítems en el canvas usando la regla de anidamiento.
     */
    private void repositionAll() {
        // Pila: cada int[] = {anchoInterioPx, coordYDelPisoInterior}
        java.util.Stack<int[]> containers = new java.util.Stack<int[]>();
        int towerTopY = CANVAS_BASE_Y;

        for (StackableItem item : items) {
            int w  = item.getWidthPixels();
            int hPx = item.getHeightPixels();

            // Desapilar donde no cabe
            while (!containers.isEmpty() && w >= containers.peek()[0]) {
                containers.pop();
            }

            int itemTopY;

            if (containers.isEmpty()) {
                // Va encima de la cima actual
                itemTopY    = towerTopY - hPx;
                towerTopY   = itemTopY;
            } else {
                // Va dentro del contenedor: apoyado en su piso interior
                itemTopY = containers.peek()[1] - hPx;
                // towerTopY NO cambia
            }

            int itemLeftX = CANVAS_CENTER_X - w / 2;
            item.moveTo(itemLeftX, itemTopY);

            // Solo los contenedores (Cup) van a la pila
            if (item.isContainer()) {
                int interiorW     = item.getInteriorWidth();
                int interiorFloorY = itemTopY + item.getInteriorFloorOffset();
                containers.push(new int[]{ interiorW, interiorFloorY });
            }
        }
    }
    // Ordenamiento (privado)
    /**
     * Ordena los ítems colocando los de mayor heightCm en la base.
     *   1. Separar las listas de tazas (isContainer=true) y tapas.
     *   2. Ordenar las tazas por heightCm descendente (burbuja).
     *   3. Reconstruir: por cada taza, agregar su tapa si existe.
     *   4. Tapas sin taza → al final.
     */
    private void sortItemsByHeightDescending() {
        ArrayList<StackableItem> cups = new ArrayList<StackableItem>();
        ArrayList<StackableItem> lids = new ArrayList<StackableItem>();
        for (StackableItem item : items) {
            if (item.isContainer()) cups.add(item);
            else                    lids.add(item);
        }
        // Burbuja descendente por heightCm
        for (int i = 0; i < cups.size() - 1; i++) {
            for (int j = 0; j < cups.size() - i - 1; j++) {
                if (cups.get(j).getHeightCm() < cups.get(j + 1).getHeightCm()) {
                    StackableItem tmp = cups.get(j);
                    cups.set(j, cups.get(j + 1));
                    cups.set(j + 1, tmp);
                }
            }
        }
        // Reconstruir: taza + su tapa (si existe)
        items.clear();
        for (StackableItem cup : cups) {
            items.add(cup);
            for (StackableItem lid : lids) {
                if (lid.getItemNumber() == cup.getItemNumber()) {
                    items.add(lid);
                    break;
                }
            }
        }
        // Tapas sin taza al final
        for (StackableItem lid : lids) {
            if (findItemByTypeAndNumber("cup", lid.getItemNumber()) == null) {
                items.add(lid);
            }
        }
    }
    // Auxiliares de búsqueda (privado)
    /**
     * Devuelve el índice en 'items' del ítem con el tipo y número dados.
     * Usa getItemType() y getItemNumber() en lugar de instanceof.
     *
     * @return índice encontrado, o -1 si no existe
     */
    private int findItemIndex(String[] id) {
        if (id == null || id.length < 2) return -1;
        String type = id[0];
        int    num  = Integer.parseInt(id[1]);
        for (int i = 0; i < items.size(); i++) {
            StackableItem item = items.get(i);
            if (type.equals(item.getItemType()) && num == item.getItemNumber()) return i;
        }
        return -1;
    }
    /**
     * Devuelve el objeto StackableItem con el tipo y número dados, o null si no existe.
     */
    private StackableItem findItemByTypeAndNumber(String type, int number) {
        for (StackableItem item : items) {
            if (type.equals(item.getItemType()) && number == item.getItemNumber()) return item;
        }
        return null;
    }
    /**
     * Devuelve el índice del último ítem del tipo dado ("cup" o "lid").
     */
    private int lastIndexOfType(String type) {
        for (int i = items.size() - 1; i >= 0; i--) {
            if (type.equals(items.get(i).getItemType())) return i;
        }
        return -1;
    }
    /**
     * Devuelve el índice real del n-ésimo ítem del tipo dado (n empieza en 0).
     */
    private int realIndexOfNthOfType(String type, int n) {
        int count = 0;
        for (int i = 0; i < items.size(); i++) {
            if (type.equals(items.get(i).getItemType())) {
                if (count == n) return i;
                count++;
            }
        }
        return -1;
    }
    /**
     * Desmarca la taza con el número dado, si existe en la torre.
     * Llama notifyCover(false) que Cup atiende restaurando su color.
     */
    private void uncoverMatchingCup(int cupNumber) {
        StackableItem cup = findItemByTypeAndNumber("cup", cupNumber);
        if (cup != null) cup.notifyCover(false);
    }
    /** Crea el arreglo identificador {"tipo", "número"} de un ítem. */
    private String[] toIdentifier(StackableItem item) {
        return new String[]{ item.getItemType(), String.valueOf(item.getItemNumber()) };
    }
    // Regla lateral 
    private void buildScaleRule() {
        if (!isDisplayed) return;
        int totalCm = height();
        if (totalCm == 0) return;
        int ruleX = 32;
        for (int cm = 0; cm <= totalCm; cm++) {
            int tickY    = CANVAS_BASE_Y - (cm * Cup.PIXELS_PER_CM) - 1;
            boolean major = (cm % 5 == 0);
            int len      = major ? 12 : 6;
            Rectangle tick = new Rectangle();
            tick.changeColor("black");
            tick.changeSize(2, len);
            tick.moveHorizontal((ruleX - len) - 70);
            tick.moveVertical(tickY - 15);
            tick.makeVisible();
            scaleMarks.add(tick);
        }
    }
    private void hideScaleRule() {
        for (Rectangle r : scaleMarks) r.makeInvisible();
        scaleMarks.clear();
    }
    private void rebuildScale() {
        if (isDisplayed) { hideScaleRule(); buildScaleRule(); }
    }
    // Utilidades (privado)
    private void fail(String msg) {
        lastOpOk = false;
        if (isDisplayed) javax.swing.JOptionPane.showMessageDialog(null, "ERROR: " + msg);
    }
    private String colorForNumber(int n) {
        return PALETTE[(n - 1) % PALETTE.length];
    }
}
