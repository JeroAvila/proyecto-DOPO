import shapes.*;
/**
 * Modela una taza (cup) que puede apilarse en la torre.
 * @author Avila - Bernal
 * @version 3 - Ciclo 2
 */
public class Cup implements StackableItem {
    /**
     * ATRIBUTOS  (usadas también por Lid y Tower)
     */
    // Píxeles equivalentes a 1 cm lógico (para la regla de la torre). */
    public static final int PIXELS_PER_CM  = 15;
    // Grosor de las paredes y fondo de la taza en píxeles. 
    public static final int WALL_THICKNESS = 5;
    // Número identificador de la taza (>= 1). 
    private int number;

    /** Altura lógica en cm: 2^(number-1). Calculada al construir. */
    private int heightCm;

    /** Color actual de la taza. Cambia al taparse/destaparse. */
    private String color;

    /** Color original asignado al crear la taza (para restaurar al destapar). */
    private String originalColor;

    /** True si la taza tiene su tapa en la torre (marcada por Tower.cover()). */
    private boolean covered;

    /** True si la taza está actualmente visible en el canvas. */
    private boolean showing;
    
    private static final String COVERED_COLOR = "cyan";

    // Atributos visuales 


    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle bottomBar;

    // Posición interna actual de cada rectángulo (para mover de forma relativa)
    private int leftX,  leftY;
    private int rightX, rightY;
    private int botX,   botY;

    // Constructor
    /**
     * Crea una taza con número y color dados.
     *
     * @param number número identificador (>= 1)
     * @param color  color inicial
     */
    public Cup(int number, String color) {
        this.number        = number;
        this.color         = color;
        this.originalColor = color;
        this.covered       = false;
        this.showing       = false;
        this.heightCm      = computeHeightCm(number);
        buildVisualShape();
    }
    // Implementación de StackableItem
    /**
     * Ancho total de la taza: 40 + number * 30 px.
     * Cup1=70, Cup2=100, Cup3=130, Cup4=160, ...
     */
    public int getWidthPixels() {
        return 40 + (number * 30);
    }
    /**
     * Altura lógica de la taza en cm: 2^(number-1).
     * Cup1=1cm, Cup2=2cm, Cup3=4cm, Cup4=8cm, ...
     */
    public int getHeightCm() {
        return heightCm;
    }
    /**
     * Alto visual: 20 + number * 25 px.
     * Distinto del alto lógico para que Cup1 sea visible en pantalla.
     */
    public int getHeightPixels() {
        return 20 + (number * 25);
    }
    /**
     * Ancho interior de la taza: ancho - 2 * WALL_THICKNESS.
     * Es el espacio donde puede entrar otra taza o tapa más pequeña.
     * Tower lo usa para decidir si un ítem "cabe dentro".
     */
    public int getInteriorWidth() {
        return getWidthPixels() - 2 * WALL_THICKNESS;
    }
    /**
     * Offset en px desde el borde superior hasta el piso interno de la taza.
     * Valor: getHeightPixels() - WALL_THICKNESS.
     * Tower lo usa para calcular el Y donde se apoya lo que está dentro.
     */
    public int getInteriorFloorOffset() {
        return getHeightPixels() - WALL_THICKNESS;
    }
    /**
     * Las tazas SÍ son contenedores: pueden tener ítems dentro.
     * Tower usa esto en lugar de "item instanceof Cup".
     */
    public boolean isContainer() {
        return true;
    }
    /**
     * Tipo del ítem para stackingItems(): retorna "cup".
     * Tower usa esto en lugar de (item instanceof Cup) ? "cup" : "lid".
     */
    public String getItemType() {
        return "cup";
    }
    /**
     * Número identificador de la taza.
     * Tower usa esto para buscar ítems por tipo y número.
     */
    public int getItemNumber() {
        return number;
    }
    /** Muestra la taza en el canvas. */
    public void makeVisible() {
        if (showing) return;
        leftWall.makeVisible();
        rightWall.makeVisible();
        bottomBar.makeVisible();
        showing = true;
    }
    /** Oculta la taza del canvas. */
    public void makeInvisible() {
        if (!showing) return;
        leftWall.makeInvisible();
        rightWall.makeInvisible();
        bottomBar.makeInvisible();
        showing = false;
    }
    /**
     * Mueve la taza a (x, y) — esquina superior-izquierda.
     * Reposiciona los tres rectángulos en consecuencia.
     */
    public void moveTo(int x, int y) {
        int totalWidth  = getWidthPixels();
        int totalHeight = getHeightPixels();
        int wallHeight  = totalHeight - WALL_THICKNESS;

        int lx = x,                              ly = y;       // pared izquierda
        int rx = x + totalWidth - WALL_THICKNESS, ry = y;      // pared derecha
        int bx = x,                              by = y + wallHeight; // fondo

        leftWall.moveHorizontal(lx - leftX);
        leftWall.moveVertical  (ly - leftY);
        leftX = lx; leftY = ly;

        rightWall.moveHorizontal(rx - rightX);
        rightWall.moveVertical  (ry - rightY);
        rightX = rx; rightY = ry;

        bottomBar.moveHorizontal(bx - botX);
        bottomBar.moveVertical  (by - botY);
        botX = bx; botY = by;
    }
    /**
     * Cambia el color de la taza.
     * Tower.cover() llama setColor("cyan") para indicar que está tapada.
     */
    public void setColor(String newColor) {
        this.color = newColor;
        leftWall.changeColor(newColor);
        rightWall.changeColor(newColor);
        bottomBar.changeColor(newColor);
    }
    /** Devuelve el color actual de la taza. */
    public String getColor() {
        return color;
    }
    // Métodos exclusivos de Cup (no están en la interfaz)
    /**
     * Marca o desmarca la taza como tapada.
     * Al desmarcar, restaura automáticamente el color original.
     * Llamado por Tower.cover() y Tower.uncoverCupIfPresent().
     * @param isCovered true = tiene tapa; false = no tiene tapa
     */
    public void setCovered(boolean isCovered) {
        this.covered = isCovered;
        if (isCovered) {
            setColor(COVERED_COLOR); // restaurar al destapar
        }else {
            setColor(originalColor);
        }
    }
    /** @return true si esta taza está marcada como tapada. */
    public boolean isCovered() {
        return covered;
    }
    /**
     * Implementación de StackableItem.notifyCover().
     * Cuando covered=true: marca la taza (Tower le cambiará el color).
     * Cuando covered=false: desmarca y restaura el color original.
     */
    public void notifyCover(boolean covered) {
        setCovered(covered);
    }
    // Privados
    /** Calcula la altura lógica: 2^(n-1) cm. */
    private int computeHeightCm(int n) {
        int h = 1;
        for (int i = 0; i < n - 1; i++) h *= 2;
        return h;
    }
    /**
     * Construye los tres rectángulos y los lleva al origen (0,0).
     * BlueJ inicializa Rectangle en (70,15); compensamos ese desfase.
     */
    private void buildVisualShape() {
        int totalWidth  = getWidthPixels();
        int totalHeight = getHeightPixels();
        int wallHeight  = totalHeight - WALL_THICKNESS;

        leftWall = new Rectangle();
        leftWall.changeColor(color);
        leftWall.changeSize(wallHeight, WALL_THICKNESS);
        leftWall.moveHorizontal(-70);
        leftWall.moveVertical(-15);
        leftX = 0; leftY = 0;

        rightWall = new Rectangle();
        rightWall.changeColor(color);
        rightWall.changeSize(wallHeight, WALL_THICKNESS);
        rightWall.moveHorizontal(-70);
        rightWall.moveVertical(-15);
        rightX = 0; rightY = 0;

        bottomBar = new Rectangle();
        bottomBar.changeColor(color);
        bottomBar.changeSize(WALL_THICKNESS, totalWidth);
        bottomBar.moveHorizontal(-70);
        bottomBar.moveVertical(-15);
        botX = 0; botY = 0;
    }
}
