/**
 * Excepcion propia del simulador de torres que se pueden apilar
 * ciclo 3
 * reemplaza el patrón de marcar lastOpOk = false
 * Esto permite al llamador saber exactamente que salió mal
 * 
 * @nombres Avila - Bernal 
 * @version (1.0) */
public class TowerException extends Exception {
    
    // atributos y constantes
    
    // Numero de taza o tapa invalido <1.
    public static final int INVALID_NUMBER = 1;
    // pop en una torre sin tazas.
    public static final int NO_CUPS = 2;
    // pop en una torre sin tapas.
    public static final int NO_LIDS = 3;
    // posicion fuera del rango valido de tazas.
    public static final int INVALID_CUP_POSITION = 4;
    // posicion fuera del rango valido de tapas.
    public static final int INVALID_LID_POSITION = 5;
    // Uno o ambos items de swap no existen en la torre
    public static final int ITEM_NOT_FOUND = 6;
    // Crea una torre con cero o menos tazas.
    public static final int INVALID_TOWER_SIZE = 7;
    // torre vacia cuando se repite un item
    public static final int EMPTY_TOWER = 8;
    // codigo de error tipado   
    private int errorCode;
    
    /**
     * Contructor
     * 
     * Crea una TowerException con un código de error
     * crea un mensaje descriptivo
     * 
     * @param errorCode codigo error
     * @param message descripcion del error
     */
    public TowerException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
    /**
     * devuelve el codigo del error tipado
     */
    public int getErrorCode(){
        return errorCode;
    }
}
