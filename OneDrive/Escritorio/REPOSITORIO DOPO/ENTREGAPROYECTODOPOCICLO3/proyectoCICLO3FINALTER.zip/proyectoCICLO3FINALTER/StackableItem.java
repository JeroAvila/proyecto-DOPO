/**
 * Interfaz que representa cualquier objeto que puede apilarse en la torre.
 *
 * @author Avila - Bernal
 * @version 3 - Ciclo 2
 */
public interface StackableItem {
    // Dimensiones 
    /**
     * Ancho total del ítem en píxeles.
     * Regla de anidamiento: ítem B cabe dentro de A si
     *     B.getWidthPixels() < A.getInteriorWidth()
     */
    int getWidthPixels();
    /**
     * Altura lógica del ítem en centímetros.
     * Usada por Tower.height() para sumar la altura total.
     */
    int getHeightCm();
    /**
     * Altura visual del ítem en píxeles.
     * Usada por Tower.repositionAll() para posicionar en el canvas.
     */
    int getHeightPixels();
    /**
     * Ancho interior del ítem en píxeles (el espacio donde puede entrar otro ítem).
     * Para Cup: getWidthPixels() - 2 * WALL_THICKNESS
     * Para Lid: 0  (las tapas no son contenedores)
     */
    int getInteriorWidth();
    /**
     * Offset en píxeles desde la coordenada Y superior del ítem hasta su piso interior.
     * Para Cup: getHeightPixels() - WALL_THICKNESS
     * Para Lid: 0  (las tapas no tienen piso interior)
     */
    int getInteriorFloorOffset();
    /**
     * Indica si este ítem puede actuar como contenedor (recibir ítems dentro).
     * Cup → true     Lid → false
     */
    boolean isContainer();
    // Identidad (usadas por Tower.stackingItems() y búsquedas()
    /**
     * Tipo del ítem como string: "cup" o "lid".
     * Reemplaza el patrón: (item instanceof Cup) ? "cup" : "lid"
     */
    String getItemType();
    /**
     * Número identificador del ítem.
     * Para Cup: el número de la taza.
     * Para Lid: el número de la taza a la que pertenece.
     */
    int getItemNumber();
    // Visual
    /** Muestra el ítem en el canvas de BlueJ. */
    void makeVisible();
    /** Oculta el ítem del canvas de BlueJ. */
    void makeInvisible();
    /**
     * Mueve el ítem para que su esquina superior-izquierda quede en (x, y).
     *
     * @param x coordenada X destino
     * @param y coordenada Y destino
     */
    void moveTo(int x, int y);
    /**
     * Cambia el color del ítem.
     * Tower lo usa para marcar visualmente las tazas tapadas.
     *
     * @param color nombre del color (ej: "blue", "red", "cyan")
     */
    void setColor(String color);
    /** Devuelve el color actual del ítem. */
    String getColor();
    /**
     * Notifica al ítem si está siendo tapado o destapado.
     *
     * Cup responde cambiando su estado 'covered' y restaurando su color original
     * cuando se destapa.
     * Lid ignora esta llamada (las tapas no pueden estar tapadas).
     *
     * Este método existe para eliminar el patrón:
     *   if (item instanceof Cup) ((Cup) item).setCovered(true);
     * Reemplazado por:
     *   item.notifyCover(true);
     *
     * @param covered true = se tapa; false = se destapa
     */
    void notifyCover(boolean covered);
}
