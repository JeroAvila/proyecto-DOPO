import shapes.*;
/**
 * Modela la tapa (lid) de una taza que puede apilarse en la torre.
 * @author Avila - Bernal
 * @version 3 - Ciclo 2
 */
public class Lid implements StackableItem {
    // Constantes
    
    // Altura visual de la tapa en píxeles (igual al grosor de pared de Cup). 
    public static final int LID_VISUAL_HEIGHT = Cup.WALL_THICKNESS;

    // Altura lógica de la tapa en cm (siempre 1). 
    public static final int LID_HEIGHT_CM     = 1;
    
    // Atributos
    
    // Número de la taza a la que pertenece esta tapa. 
    private int associatedCupNumber;
    // Color de la tapa. */
    private String color;
    // True si la tapa está visible en el canvas. 
    private boolean showing;
    // Rectángulo que representa visualmente la tapa. 
    private Rectangle visualShape;
    // Posición interna actual del rectángulo (para moveHorizontal/moveVertical relativos)
    private int shapeX;
    private int shapeY;
    
    // Constructor
    
    /**
     * Crea la tapa para la taza con el número indicado.
     *
     * @param cupNumber número de la taza propietaria (>= 1)
     * @param color     color de la tapa
     */
    public Lid(int cupNumber, String color) {
        this.associatedCupNumber = cupNumber;
        this.color   = color;
        this.showing = false;
        buildVisualShape();
    }
    // Implementación de StackableItem
    /**
     * Ancho de la tapa: 40 + associatedCupNumber * 30 px.
     * Igual al ancho de su taza. Solo cabe dentro de una taza con número mayor.
     */
    public int getWidthPixels() {
        return 40 + (associatedCupNumber * 30);
    }
    /**
     * Altura lógica de la tapa: siempre 1 cm.
     */
    public int getHeightCm() {
        return LID_HEIGHT_CM;
    }

    /**
     * Altura visual de la tapa: Cup.WALL_THICKNESS px (barra fina).
     */
    public int getHeightPixels() {
        return LID_VISUAL_HEIGHT;
    }
    /**
     * Las tapas NO tienen interior: retorna 0.
     * Ningún ítem puede caber dentro de una tapa.
     * Tower usa esto (junto con isContainer()) para no empujar una tapa
     * como contenedor en la pila de anidamiento.
     */
    public int getInteriorWidth() {
        return 0;
    }
    /**
     * Sin piso interior: retorna 0.
     * Tower solo consulta este valor si isContainer() es true.
     */
    public int getInteriorFloorOffset() {
        return 0;
    }
    /**
     * Las tapas NO son contenedores: retorna false.
     * Tower usa esto en lugar de "item instanceof Cup" para decidir si
     * puede anidar ítems dentro.
     */
    public boolean isContainer() {
        return false;
    }
    /**
     * Tipo del ítem: retorna "lid".
     * Tower usa esto en lugar de (item instanceof Lid) ? "lid" : "cup".
     */
    public String getItemType() {
        return "lid";
    }
    /**
     * Número de la taza a la que pertenece esta tapa.
     * Tower lo usa para buscar la taza matching en lidedCups() y cover().
     */
    public int getItemNumber() {
        return associatedCupNumber;
    }
    /** Muestra la tapa en el canvas. */
    public void makeVisible() {
        if (showing) return;
        visualShape.makeVisible();
        showing = true;
    }
    /** Oculta la tapa del canvas. */
    public void makeInvisible() {
        if (!showing) return;
        visualShape.makeInvisible();
        showing = false;
    }
    /**
     * Mueve la tapa a (x, y) — esquina superior-izquierda.
     */
    public void moveTo(int x, int y) {
        visualShape.moveHorizontal(x - shapeX);
        visualShape.moveVertical  (y - shapeY);
        shapeX = x;
        shapeY = y;
    }
    /**
     * Cambia el color de la tapa.
     */
    public void setColor(String newColor) {
        this.color = newColor;
        visualShape.changeColor(newColor);
    }
    /** Devuelve el color actual de la tapa. */
    public String getColor() {
        return color;
    }
    /**
     * Implementación de StackableItem.notifyCover().
     * Las tapas no pueden ser "tapadas": este método no hace nada.
     * Existe solo para cumplir con la interfaz y evitar instanceof en Tower.
     */
    public void notifyCover(boolean covered) {
        // Las tapas no tienen estado "covered": se ignora
    }
    // Privados
    /**
     * Crea el rectángulo de la tapa y lo lleva al origen (0,0).
     * BlueJ inicializa Rectangle en (70,15); compensamos ese desfase.
     */
    private void buildVisualShape() {
        int width = getWidthPixels();
        visualShape = new Rectangle();
        visualShape.changeColor(color);
        visualShape.changeSize(LID_VISUAL_HEIGHT, width);
        visualShape.moveHorizontal(-70);
        visualShape.moveVertical(-15);
        shapeX = 0;
        shapeY = 0;
    }
}
