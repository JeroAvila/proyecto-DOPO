import shapes.*;
/**
 * Modela la tapa normal de una taza apilable en la torre.
 * Ciclo 4 clase base de FearfulLid, CrazyLid y CollapseLid.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class Lid implements StackableItem {
    public static final int LID_VISUAL_HEIGHT = Cup.WALL_THICKNESS;
    public static final int LID_HEIGHT_CM     = 1;
    private int associatedCupNumber;
    private String color;
    private boolean showing;
    private Rectangle visualShape;
    private int shapeX, shapeY;
    /**
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @param color     color de la tapa
     */
    public Lid(int cupNumber, String color) {
        this.associatedCupNumber = cupNumber;
        this.color   = color;
        this.showing = false;
        buildVisualShape();
    }
    @Override public int getWidthPixels()        { return 40 + (associatedCupNumber * 30); }
    @Override public int getHeightCm()            { return LID_HEIGHT_CM; }
    @Override public int getHeightPixels()        { return LID_VISUAL_HEIGHT; }
    @Override public int getInteriorWidth()       { return 0; }
    @Override public int getInteriorFloorOffset() { return 0; }
    @Override public boolean isContainer()        { return false; }
    @Override public String getItemType()         { return "lid"; }
    @Override public String getSubtype()          { return "normal"; }
    @Override public int getItemNumber()          { return associatedCupNumber; }
    @Override
    public void makeVisible() {
        if (showing) return;
        visualShape.makeVisible();
        showing = true;
    }
    @Override
    public void makeInvisible() {
        if (!showing) return;
        visualShape.makeInvisible();
        showing = false;
    }
    @Override
    public void moveTo(int x, int y) {
        visualShape.moveHorizontal(x - shapeX);
        visualShape.moveVertical(y - shapeY);
        shapeX = x; shapeY = y;
    }
    @Override
    public void setColor(String newColor) {
        this.color = newColor;
        visualShape.changeColor(newColor);
    }
    @Override public String getColor() { return color; }
    /** Las tapas normales ignoran notifyCover. */
    @Override public void notifyCover(boolean covered) { }
    private void buildVisualShape() {
        visualShape = new Rectangle();
        visualShape.changeColor(color);
        visualShape.changeSize(LID_VISUAL_HEIGHT, getWidthPixels());
        visualShape.moveHorizontal(-70);
        visualShape.moveVertical(-15);
        shapeX = 0; shapeY = 0;
    }
}