/**
 * CAMBIAR
 * Tapa STICKY (pegajosa) — tipo propuesto por el equipo.
 * Al removerse (pop o remove), arrastra consigo a su taza companiera.
 * Permite desapilar pares taza-tapa en una sola operacion.
 * Distincion visual: color yellow.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class StickyLid extends Lid {
    /**
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @param color     color base (se sobreescribe a yellow)
     */
    public StickyLid(int cupNumber, String color) {
        super(cupNumber, color);
        super.setColor("yellow");
    }
    @Override
    public String getSubtype() { return "sticky"; }
}