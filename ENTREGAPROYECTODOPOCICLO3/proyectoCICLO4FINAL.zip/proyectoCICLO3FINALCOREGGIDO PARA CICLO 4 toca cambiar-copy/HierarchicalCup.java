/**
 * al entrar desplaza items de menor tamano hacia arriba.
 * Si llega al fondo queda anclada y no se puede remover.
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class HierarchicalCup extends Cup {
    /** True si esta taza ya llego al fondo y esta bloqueada. */
    private boolean anchored;
    /**
     * @param number numero identificador (>= 1)
     * @param color  color base (se sobreescribe a magenta)
     */
    public HierarchicalCup(int number, String color) {
        super(number, color);
        this.anchored = false;
        super.setColor("magenta");
    }
    @Override
    public String getSubtype() { return "hierarchical"; }
    /**
     * Tower llama este metodo cuando la taza llega a la posicion 0.
     * @param anchored true = anclada al fondo
     */
    public void setAnchored(boolean anchored) { this.anchored = anchored; }
    /** @return true si esta anclada y no puede removerse */
    public boolean isAnchored() { return anchored; }
}