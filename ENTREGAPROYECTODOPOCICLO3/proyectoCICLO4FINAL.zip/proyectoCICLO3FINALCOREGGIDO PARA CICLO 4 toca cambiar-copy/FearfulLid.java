/**
 * No entra a la torre si su taza compañera NO esta presente.
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class FearfulLid extends Lid {
    /**
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @param color     color base (se sobreescribe a pink)
     */
    public FearfulLid(int cupNumber, String color) {
        super(cupNumber, color);
        super.setColor("pink");
    }
    @Override
    public String getSubtype() { return "fearful"; }
}