/**
 * al entrar elimina todas las tapas que le impiden el paso.
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class OpenerCup extends Cup {
    /**
     * @param number numero identificador 
     * @param color  color base 
     */
    public OpenerCup(int number, String color) {
        super(number, color);
        super.setColor("orange");
    }
    @Override
    public String getSubtype() { return "opener"; }
}