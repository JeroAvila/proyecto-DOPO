/**
 * Tapa COLLAPSE (derrumbe) — tipo propuesto por el equipo para el Ciclo 4.
 *
 * Comportamiento especial:
 *   Al ser agregada a la torre (pushLid), dispara una animacion de
 *   "derrumbe": todos los items de la torre caen visualmente hasta el
 *   fondo del canvas uno por uno con un breve retardo entre cada uno,
 *   y luego regresan a su posicion correcta desde abajo hacia arriba.
 *
 *   El efecto es completamente visual: la logica interna (orden de items,
 *   altura, tapas) NO cambia. Solo la posicion en pantalla se anima.
 *
 *   Al ser removida (popLid o removeLid), dispara el mismo efecto de
 *   derrumbe como "despedida" antes de salir.
 *
 * Distincion visual: color MAGENTA, unica tapa de ese color en la torre.
 *
 * Implementacion de la animacion:
 *   La animacion corre en un hilo separado (Thread) para no bloquear
 *   BlueJ. Cada item se mueve hacia abajo en pasos usando moveTo(),
 *   con Thread.sleep() entre cada paso para crear el efecto de caida.
 *   Luego se llama a repositionAll() desde Tower para restaurar posiciones.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class CollapseLid extends Lid {

    /** Pixeles que cae cada item en cada frame de la animacion. */
    public static final int FALL_STEP_PX   = 18;

    /** Milisegundos de espera entre frames (controla velocidad de caida). */
    public static final int FRAME_DELAY_MS = 28;

    /** Retardo entre el inicio de caida de cada item (efecto cascada). */
    public static final int ITEM_DELAY_MS  = 60;

    /** Posicion Y del fondo del canvas donde "aterrizan" los items. */
    public static final int FLOOR_Y        = 540;

    /**
     * Crea una tapa collapse.
     *
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @param color     color base (se sobreescribe a magenta)
     */
    public CollapseLid(int cupNumber, String color) {
        super(cupNumber, color);
        super.setColor("magenta");
    }

    @Override
    public String getSubtype() { return "collapse"; }
}
