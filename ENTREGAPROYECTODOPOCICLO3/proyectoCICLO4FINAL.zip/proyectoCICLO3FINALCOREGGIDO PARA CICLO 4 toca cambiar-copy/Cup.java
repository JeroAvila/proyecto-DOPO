import shapes.*;

/**
 * Modela una taza normal apilable en la torre.
 * Ciclo 4: clase base para OpenerCup y HierarchicalCup.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class Cup implements StackableItem {

    public static final int PIXELS_PER_CM  = 15;
    public static final int WALL_THICKNESS = 5;
    public static final String COVERED_COLOR = "cyan";

    private int number;
    private int heightCm;
    private String color;
    private String originalColor;
    private boolean covered;
    private boolean showing;

    private Rectangle leftWall;
    private Rectangle rightWall;
    private Rectangle bottomBar;
    private int leftX, leftY;
    private int rightX, rightY;
    private int botX,  botY;
    /**
     * @param number numero identificador (>= 1)
     * @param color  color inicial
     */
    public Cup(int number, String color) {
        this.number        = number;
        this.color         = color;
        this.originalColor = color;
        this.covered       = false;
        this.showing       = false;
        this.heightCm      = computeHeightCm(number);
        buildVisualShape();
    }
    @Override public int getWidthPixels()       { return 40 + (number * 30); }
    @Override public int getHeightCm()           { return heightCm; }
    @Override public int getHeightPixels()       { return 20 + (number * 25); }
    @Override public int getInteriorWidth()      { return getWidthPixels() - 2 * WALL_THICKNESS; }
    @Override public int getInteriorFloorOffset(){ return getHeightPixels() - WALL_THICKNESS; }
    @Override public boolean isContainer()       { return true; }
    @Override public String getItemType()        { return "cup"; }
    @Override public String getSubtype()         { return "normal"; }
    @Override public int getItemNumber()         { return number; }
    @Override
    public void makeVisible() {
        if (showing) return;
        leftWall.makeVisible(); rightWall.makeVisible(); bottomBar.makeVisible();
        showing = true;
    }
    @Override
    public void makeInvisible() {
        if (!showing) return;
        leftWall.makeInvisible(); rightWall.makeInvisible(); bottomBar.makeInvisible();
        showing = false;
    }
    @Override
    public void moveTo(int x, int y) {
        int wh = getHeightPixels() - WALL_THICKNESS;
        int lx = x, ly = y;
        int rx = x + getWidthPixels() - WALL_THICKNESS, ry = y;
        int bx = x, by = y + wh;

        leftWall.moveHorizontal(lx - leftX); leftWall.moveVertical(ly - leftY);
        leftX = lx; leftY = ly;
        rightWall.moveHorizontal(rx - rightX); rightWall.moveVertical(ry - rightY);
        rightX = rx; rightY = ry;
        bottomBar.moveHorizontal(bx - botX); bottomBar.moveVertical(by - botY);
        botX = bx; botY = by;
    }
    @Override
    public void setColor(String newColor) {
        this.color = newColor;
        leftWall.changeColor(newColor);
        rightWall.changeColor(newColor);
        bottomBar.changeColor(newColor);
    }
    @Override public String getColor() { return color; }
    @Override
    public void notifyCover(boolean covered) {
        this.covered = covered;
        setColor(covered ? COVERED_COLOR : originalColor);
    }
    public boolean isCovered() { return covered; }
    protected String getOriginalColor() { return originalColor; }
    private int computeHeightCm(int n) {
        int h = 1;
        for (int i = 0; i < n - 1; i++) h *= 2;
        return h;
    }
    private void buildVisualShape() {
        int tw = getWidthPixels(), th = getHeightPixels(), wh = th - WALL_THICKNESS;

        leftWall = new Rectangle();
        leftWall.changeColor(color); leftWall.changeSize(wh, WALL_THICKNESS);
        leftWall.moveHorizontal(-70); leftWall.moveVertical(-15);
        leftX = 0; leftY = 0;

        rightWall = new Rectangle();
        rightWall.changeColor(color); rightWall.changeSize(wh, WALL_THICKNESS);
        rightWall.moveHorizontal(-70); rightWall.moveVertical(-15);
        rightX = 0; rightY = 0;

        bottomBar = new Rectangle();
        bottomBar.changeColor(color); bottomBar.changeSize(WALL_THICKNESS, tw);
        bottomBar.moveHorizontal(-70); bottomBar.moveVertical(-15);
        botX = 0; botY = 0;
    }
}