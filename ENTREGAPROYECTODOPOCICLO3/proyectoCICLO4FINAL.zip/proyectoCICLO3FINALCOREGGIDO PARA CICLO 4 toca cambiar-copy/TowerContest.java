import java.util.ArrayList;
import java.util.Arrays;

/**
 * Resuelve y simula el problema de la maratón Stacking Cups
 *    
 * @author Avila - Bernal
 * @version 1 - Ciclo 3
 */
public class TowerContest {
    // SOLVE  (Requisito 14)
    /**
     * Calcula el número mínimo de intercambios adyacentes necesarios para que una torre de n tazas 
     * 
     * @param n número de tazas (>= 1)
     * @param h altura máxima permitida en cm (>= 1)
     * @return String con el número de swaps, o "impossible"
     */
    public static String solve(int n, int h) {
        if (n < 1 || h < 1) return "impossible";

        // Altura mínima posible: permutación n, n-1, ..., 1
        int minHeight = heightCm(n); // 2^(n-1)
        if (minHeight > h) return "impossible";

        // Permutación inicial: [1, 2, 3, ..., n] 
        int[] initial = new int[n];
        for (int i = 0; i < n; i++) initial[i] = i + 1;

        // Si la altura inicial ya cumple
        if (computeHeight(initial) <= h) return "0";

        // Para n <= 8 se puede hacer BFS exacto 
        if (n <= 8) {
            return String.valueOf(bfsMinSwaps(initial, h));
        }
        return String.valueOf(greedyMinSwaps(initial, h));
    }
    // SIMULATE
    /**
     * Simula visualmente la solución del problema.
     * Crea una instancia de Tower
     * 
     * @param n número de tazas (>= 1)
     * @param h altura máxima permitida en cm (>= 1)
     */
    public static void simulate(int n, int h) {
        String result = solve(n, h);
        if ("impossible".equals(result)) {
            javax.swing.JOptionPane.showMessageDialog(
                null,
                "No es posible reducir la torre de " + n +
                " tazas a una altura <= " + h + " cm.\n" +
                "Altura mínima posible: " + heightCm(n) + " cm.",
                "Stacking Cups – Impossible",
                javax.swing.JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        // Obtener la secuencia de swaps
        int[] initial = new int[n];
        for (int i = 0; i < n; i++) initial[i] = i + 1;

        ArrayList<int[]> swapSequence = (n <= 8)
            ? bfsSwapSequence(initial, h)
            : greedySwapSequence(initial, h);
        // Crear y mostrar la torre en el canvas
        Tower tower = new Tower(500, 300);
        // Construir torre en orden inicial 1..n 
        try {
            for (int i = n; i >= 1; i--) {
                tower.pushCup(i);
            }
        } catch (TowerException e) {
            javax.swing.JOptionPane.showMessageDialog(null,
                "Error al construir la torre: " + e.getMessage());
            return;
        }
        // pantalla de carga/resumen que pausa la ejecución esperando que el usuario presione OK 
        // solo entonces el código continúa ejecutando los swaps uno a uno sobre la torre visible.
        tower.makeVisible();
        sleep(1000);
        // Mostrar mensaje inicial
        javax.swing.JOptionPane.showMessageDialog(
            null,
            "Torre inicial (1 a " + n + ", base a cima).\n" +
            "Altura actual: " + computeHeight(initial) + " cm\n" +
            "Objetivo: <= " + h + " cm\n" +
            "Swaps necesarios: " + result + "\n\nPresiona OK para animar.",
            "Stacking Cups – Simulate",
            javax.swing.JOptionPane.INFORMATION_MESSAGE
        );
        int[] current = Arrays.copyOf(initial, n);
        for (int[] swap : swapSequence) {
            int posA = swap[0]; // índice en el arreglo (base=0)
            int posB = swap[1];
            int cupA = current[posA];
            int cupB = current[posB];
            try {
                tower.swap("cup", cupA, "cup", cupB);
            } catch (TowerException e) {
                // no debería ocurrir
            }
            // actualizar arreglo local
            int tmp = current[posA];
            current[posA] = current[posB];
            current[posB] = tmp;

            sleep(600);
        }
        // Mensaje final
        javax.swing.JOptionPane.showMessageDialog(
            null,
            "¡Listo! Altura final: " + computeHeight(current) + " cm (<= " + h + " cm).\n" +
            "Se realizaron " + swapSequence.size() + " swap(s).",
            "Stacking Cups – Completado",
            javax.swing.JOptionPane.INFORMATION_MESSAGE
        );
    }
    // MÉTODOS PRIVADOS DE RESOLUCIÓN
    /**
     * Calcula la altura total de una permutación de tazas.
     * @param perm arreglo de números de taza [base..cima]
     * @return altura total en cm
     */
    static int computeHeight(int[] perm) {
        // Pila de anchos interiores activos
        java.util.Stack<Integer> interiors = new java.util.Stack<>();
        int total = 0;
        for (int cup : perm) {
            int w = widthPixels(cup);
            // desapilar contenedores donde el ítem no cabe
            while (!interiors.isEmpty() && w >= interiors.peek()) {
                interiors.pop();
            }
            if (interiors.isEmpty()) {
                total += heightCm(cup);
                interiors.push(interiorWidth(cup));
            } else {
                // cabe dentro: no suma, pero sí puede ser contenedor
                interiors.push(interiorWidth(cup));
            }
        }
        return total;
    }
    /**
     * BFS sobre el espacio de permutaciones para encontrar el mínimo
     * número de swaps adyacentes que lleva a height <= h.
     * Solo viable para n <= 8.
     *
     * @return número mínimo de swaps, o Integer.MAX_VALUE si no es posible
     */
    private static int bfsMinSwaps(int[] initial, int h) {
        // Estado: permutación codificada como String
        String startKey = permKey(initial);
        java.util.Map<String, Integer> visited = new java.util.HashMap<>();
        java.util.Queue<int[]> queue = new java.util.LinkedList<>();

        visited.put(startKey, 0);
        queue.add(Arrays.copyOf(initial, initial.length));

        while (!queue.isEmpty()) {
            int[] perm = queue.poll();
            int swaps = visited.get(permKey(perm));

            if (computeHeight(perm) <= h) return swaps;

            int n = perm.length;
            for (int i = 0; i < n - 1; i++) {
                int[] next = Arrays.copyOf(perm, n);
                int tmp = next[i]; next[i] = next[i+1]; next[i+1] = tmp;
                String key = permKey(next);
                if (!visited.containsKey(key)) {
                    visited.put(key, swaps + 1);
                    queue.add(next);
                }
            }
        }
        return Integer.MAX_VALUE;
    }
    /**
     * BFS que también devuelve la secuencia de swaps [posA, posB].
     */
    private static ArrayList<int[]> bfsSwapSequence(int[] initial, int h) {
        String startKey = permKey(initial);
        java.util.Map<String, String[]> parent = new java.util.HashMap<>();
        // parent[key] = {parentKey, swapA, swapB}
        java.util.Queue<int[]> queue = new java.util.LinkedList<>();

        parent.put(startKey, null);
        queue.add(Arrays.copyOf(initial, initial.length));

        String goalKey = null;
        outer:
        while (!queue.isEmpty()) {
            int[] perm = queue.poll();
            String key = permKey(perm);

            if (computeHeight(perm) <= h) {
                goalKey = key;
                break;
            }

            int n = perm.length;
            for (int i = 0; i < n - 1; i++) {
                int[] next = Arrays.copyOf(perm, n);
                int tmp = next[i]; next[i] = next[i+1]; next[i+1] = tmp;
                String nextKey = permKey(next);
                if (!parent.containsKey(nextKey)) {
                    parent.put(nextKey, new String[]{key, String.valueOf(i), String.valueOf(i+1)});
                    queue.add(next);
                }
            }
        }
        ArrayList<int[]> path = new ArrayList<>();
        if (goalKey == null) return path;

        // Reconstruir camino
        java.util.LinkedList<int[]> steps = new java.util.LinkedList<>();
        String cur = goalKey;
        while (parent.get(cur) != null) {
            String[] info = parent.get(cur);
            steps.addFirst(new int[]{Integer.parseInt(info[1]), Integer.parseInt(info[2])});
            cur = info[0];
        }
        path.addAll(steps);
        return path;
    }
    /**
     * Greedy: mueve la taza mayor hacia la base paso a paso.
     * Para n > 8. Calcula el número de swaps.
     */
    private static int greedyMinSwaps(int[] initial, int h) {
        int[] perm = Arrays.copyOf(initial, initial.length);
        int totalSwaps = 0;
        int n = perm.length;
        // Intentar mover cada taza grande hacia la base
        for (int target = n; target >= 1; target--) {
            if (computeHeight(perm) <= h) break;
            // buscar posición de la taza 'target'
            int pos = -1;
            for (int i = 0; i < n; i++) {
                if (perm[i] == target) { pos = i; break; }
            }
            // moverla hacia la base (índice 0) con swaps adyacentes
            while (pos > 0) {
                int tmp = perm[pos]; perm[pos] = perm[pos-1]; perm[pos-1] = tmp;
                pos--;
                totalSwaps++;
                if (computeHeight(perm) <= h) return totalSwaps;
            }
        }
        return totalSwaps;
    }
    /**
     * Greedy que también devuelve la secuencia de swaps.
     */
    private static ArrayList<int[]> greedySwapSequence(int[] initial, int h) {
        int[] perm = Arrays.copyOf(initial, initial.length);
        ArrayList<int[]> sequence = new ArrayList<>();
        int n = perm.length;

        for (int target = n; target >= 1; target--) {
            if (computeHeight(perm) <= h) break;
            int pos = -1;
            for (int i = 0; i < n; i++) {
                if (perm[i] == target) { pos = i; break; }
            }
            while (pos > 0) {
                sequence.add(new int[]{pos - 1, pos});
                int tmp = perm[pos]; perm[pos] = perm[pos-1]; perm[pos-1] = tmp;
                pos--;
                if (computeHeight(perm) <= h) return sequence;
            }
        }
        return sequence;
    }
    // UTILIDADES DE DIMENSIONES 
    /** Altura en cm de la taza número n: 2^(n-1). */
    static int heightCm(int n) {
        return 1 << (n - 1); // 
    }
    /** Ancho total en píxeles de la taza n: 40 + n*30. */
    private static int widthPixels(int n) {
        return 40 + n * 30;
    }
    /** Ancho interior de la taza n: widthPixels - 2*WALL_THICKNESS (5px). */
    private static int interiorWidth(int n) {
        return widthPixels(n) - 10; 
    }
    /** Codifica una permutación como String para usarla como clave de mapa. */
    private static String permKey(int[] perm) {
        StringBuilder sb = new StringBuilder();
        for (int v : perm) { sb.append(v).append(','); }
        return sb.toString();
    }
    /** Pausa la animación. */
    private static void sleep(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { /* ignorar */ }
    }
}