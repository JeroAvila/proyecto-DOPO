import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 * Pruebas de unidad para TowerContest.
 * Cubre solve(n, h) con casos válidos, límite e imposibles.
 *
 * @author Avila - Bernal
 * @version 1 - Ciclo 3
 */
public class TowerContestTest {
    // computeHeight (auxiliar estático, ya visible como package)
    @Test
    public void heightOfOrderedDescShouldBeMaxCupOnly() {
        // [4,3,2,1] → todo anidado → solo cup4 = 2^3 = 8
        int[] perm = {4, 3, 2, 1};
        assertEquals(8, TowerContest.computeHeight(perm));
    }
    @Test
    public void heightOfOrderedAscShouldBeSumOfAll() {
        // [1,2,3,4] → ninguno anida → 1+2+4+8 = 15
        int[] perm = {1, 2, 3, 4};
        assertEquals(15, TowerContest.computeHeight(perm));
    }
    @Test
    public void heightSingleCup() {
        int[] perm = {3};
        assertEquals(4, TowerContest.computeHeight(perm)); // 2^2 = 4
    }
    // solve – casos básicos
    @Test
    public void solveAlreadySatisfied() {
        // n=1, cualquier h >= 1: height inicial = 1 → 0 swaps
        assertEquals("0", TowerContest.solve(1, 5));
    }
    @Test
    public void solveImpossibleWhenHLessThanMinHeight() {
        // n=4, minHeight = 2^3 = 8. h=7 → impossible
        assertEquals("impossible", TowerContest.solve(4, 7));
    }
    @Test
    public void solveImpossibleWhenHIsZero() {
        assertEquals("impossible", TowerContest.solve(3, 0));
    }
    @Test
    public void solveImpossibleWhenNIsZero() {
        assertEquals("impossible", TowerContest.solve(0, 10));
    }
    @Test
    public void solveZeroSwapsWhenAlreadyFits() {
        // n=4, h=15 → altura inicial [1,2,3,4] = 15 ≤ 15 → 0 swaps
        assertEquals("0", TowerContest.solve(4, 15));
    }
    @Test
    public void solveN2H1() {
        // n=2, initial=[1,2], height=1+2=3. minHeight=2^1=2
        // h=2: necesitamos [2,1] → 1 swap
        assertEquals("1", TowerContest.solve(2, 2));
    }
    @Test
    public void solveN3H4() {
 
        int swaps = Integer.parseInt(TowerContest.solve(3, 4));
        assertTrue(swaps >= 0 && swaps <= 3);
        // verificar que es el mínimo real
    }
    @Test
    public void solveN4H8() {
        String result = TowerContest.solve(4, 8);
        assertNotEquals("impossible", result);
        int swaps = Integer.parseInt(result);
        assertTrue(swaps > 0);
        assertTrue(swaps <= 6); 
    }
    @Test
    public void solveResultIsNumericOrImpossible() {
        String r = TowerContest.solve(5, 10);
        if (!"impossible".equals(r)) {
            int val = Integer.parseInt(r);
            assertTrue(val >= 0);
        }
    }
    // solve – verificación de corrección
    @Test
    public void solveN3ActuallyReducesHeight() {
        int n = 3, h = 4;
        String result = TowerContest.solve(n, h);
        assertNotEquals("impossible", result);
        int swaps = Integer.parseInt(result);

        // aplicar 'swaps' movimientos greedy y verificar altura
        int[] perm = {1, 2, 3};
        // aplicamos el algoritmo greedy para validar
        outer:
        for (int target = n; target >= 1; target--) {
            int pos = -1;
            for (int i = 0; i < n; i++) if (perm[i] == target) { pos = i; break; }
            while (pos > 0) {
                int tmp = perm[pos]; perm[pos] = perm[pos-1]; perm[pos-1] = tmp;
                pos--;
                if (TowerContest.computeHeight(perm) <= h) break outer;
            }
        }
        assertTrue(TowerContest.computeHeight(perm) <= h);
    }
    // heightCm auxiliar
    @Test
    public void heightCmIsCorrect() {
        assertEquals(1,  TowerContest.heightCm(1));
        assertEquals(2,  TowerContest.heightCm(2));
        assertEquals(4,  TowerContest.heightCm(3));
        assertEquals(8,  TowerContest.heightCm(4));
        assertEquals(16, TowerContest.heightCm(5));
    }
}