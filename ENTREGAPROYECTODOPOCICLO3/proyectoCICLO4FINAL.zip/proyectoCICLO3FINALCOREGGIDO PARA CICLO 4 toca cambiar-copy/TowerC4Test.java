
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
/**
 * Pruebas unitarias del Ciclo 4.
 * Cubre: correcciones de bugs, nuevos tipos de taza y tapa, placedLids().
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class TowerC4Test {
    private Tower tower;
    @Before
    public void setUp() throws TowerException {
        tower = new Tower(4);
    }
    //removeCup con posicion invalida → OUT_OF_BOUNDS
    /**
     * BUG CORREGIDO: remover una copa que salio del tablero (posicion invalida)
     * debe lanzar TowerException con codigo OUT_OF_BOUNDS, no ignorarse.
     */
    @Test
    public void testRemoveCupOutOfBounds() {
        try {
            tower.removeCup(99); // posicion que no existe
            fail("Debia lanzar TowerException por posicion invalida");
        } catch (TowerException e) {
            assertEquals(TowerException.OUT_OF_BOUNDS, e.getErrorCode());
        }
    }
    /**
     * BUG CORREGIDO: removeLid con posicion invalida lanza OUT_OF_BOUNDS.
     */
    @Test
    public void testRemoveLidOutOfBounds() throws TowerException {
        tower.pushLid(1);
        try {
            tower.removeLid(99);
            fail("Debia lanzar TowerException por posicion invalida");
        } catch (TowerException e) {
            assertEquals(TowerException.OUT_OF_BOUNDS, e.getErrorCode());
        }
    }
    // Mensaje de error en TODA operacion fallida
    /**
     * Toda excepcion se lanza con mensaje no vacio.
     */
    @Test
    public void testExceptionHasMessage() {
        try {
            tower.removeCup(99);
        } catch (TowerException e) {
            assertNotNull(e.getMessage());
            assertTrue(e.getMessage().length() > 0);
        }
    }
    // orderTower NO saca copas cerradas de su contenedor
    /**
     * BUG CORREGIDO: despues de cover() y orderTower(), una taza con su tapa
     * debe seguir teniendo su tapa encima (el par no se rompe).
     */
    @Test
    public void testOrderTowerKeepsCoveredCupWithLid() throws TowerException {
        tower.pushLid(2); // tapa de la taza 2
        tower.cover();    // marcar taza 2 como tapada

        tower.orderTower();

        // La taza 2 debe seguir en la torre
        String[][] stacking = tower.stackingItems();
        boolean cup2Present = false;
        boolean lid2Present = false;
        for (String[] item : stacking) {
            if ("cup".equals(item[0]) && "2".equals(item[2])) cup2Present = true;
            if ("lid".equals(item[0]) && "2".equals(item[2])) lid2Present = true;
        }
        assertTrue("La taza 2 debe estar en la torre", cup2Present);
        assertTrue("La tapa 2 debe estar en la torre", lid2Present);
    }
    // ── 4. pushLid permite tapar despues de ordenar 
    /**
     * BUG CORREGIDO: pushLid() despues de orderTower() coloca y muestra la tapa.
     */
    @Test
    public void testPushLidAfterOrderTower() throws TowerException {
        tower.orderTower();
        tower.pushLid(1); // debe funcionar sin error

        assertTrue("La operacion debe ser exitosa", tower.ok());

        String[][] lids = tower.placedLids();
        boolean lid1Found = false;
        for (String[] lid : lids) {
            if ("1".equals(lid[2])) lid1Found = true;
        }
        assertTrue("La tapa 1 debe estar en la torre", lid1Found);
    }
    // removeLid por posicion logica
    /**
     * BUG CORREGIDO: removeLid(0) elimina la primera tapa desde la base.
     */
    @Test
    public void testRemoveLidByLogicalPosition() throws TowerException {
        tower.pushLid(1);
        tower.pushLid(2);

        // Hay 2 tapas; removeLid(0) elimina la primera (lid 1 que fue la primera en entrar)
        tower.removeLid(0);
        assertTrue(tower.ok());

        String[][] lids = tower.placedLids();
        assertEquals("Debe quedar 1 tapa", 1, lids.length);
    }
    // placedLids(): lista de tapas colocadas 
    /**
     * NUEVO METODO: placedLids() devuelve correctamente las tapas presentes.
     */
    @Test
    public void testPlacedLidsEmpty() {
        String[][] lids = tower.placedLids();
        assertEquals("Sin tapas, el arreglo debe estar vacio", 0, lids.length);
    }
    @Test
    public void testPlacedLidsAfterPush() throws TowerException {
        tower.pushLid(1);
        tower.pushLid(3);

        String[][] lids = tower.placedLids();
        assertEquals("Deben haber 2 tapas", 2, lids.length);
        // Verificar que son del tipo lid
        for (String[] lid : lids) {
            assertEquals("lid", lid[0]);
        }
    }
    @Test
    public void testPlacedLidsAfterRemove() throws TowerException {
        tower.pushLid(1);
        tower.pushLid(2);
        tower.removeLid(0); // quitar primera tapa

        String[][] lids = tower.placedLids();
        assertEquals("Debe quedar 1 tapa", 1, lids.length);
    }
    // Tapas visibles inmediatamente al colocarlas
    /**
     * BUG CORREGIDO: las tapas aparecen en stackingItems() inmediatamente
     * despues de pushLid(), no solo tras un reverse.
     */
    @Test
    public void testLidAppearsImmediatelyAfterPush() throws TowerException {
        tower.pushLid(1);
        String[][] stacking = tower.stackingItems();
        boolean lidFound = false;
        for (String[] item : stacking) {
            if ("lid".equals(item[0]) && "1".equals(item[2])) {
                lidFound = true;
            }
        }
        assertTrue("La tapa debe aparecer en stackingItems inmediatamente", lidFound);
    }
    // Nuevos tipos de taza
    /**
     * OpenerCup: elimina las tapas que le impiden el paso al entrar.
     */
    @Test
    public void testOpenerCupRemovesBlockingLids() throws TowerException {
        tower.pushLid(1); // tapa 1 esta en la torre
        tower.pushLid(2); // tapa 2 esta en la torre

        tower.pushCup("opener", 3); // debe eliminar tapas con numero <= 3

        String[][] lids = tower.placedLids();
        assertEquals("OpenerCup debe haber eliminado las tapas bloqueantes", 0, lids.length);
    }
    /**
     * HierarchicalCup: subtipo correcto.
     */
    @Test
    public void testHierarchicalCupSubtype() throws TowerException {
        tower.pushCup("hierarchical", 2);
        String[][] stacking = tower.stackingItems();
        boolean found = false;
        for (String[] item : stacking) {
            if ("cup".equals(item[0]) && "hierarchical".equals(item[1]) && "2".equals(item[2])) {
                found = true;
            }
        }
        assertTrue("Debe haber una taza hierarchical 2 en la torre", found);
    }
    //  Nuevos tipos de tapa 
    /**
     * FearfulLid: no entra si su taza no esta en la torre.
     */
    @Test
    public void testFearfulLidRefusedWithoutCompanion() {
        try {
            Tower t = new Tower(500, 300);
            t.pushLid("fearful", 5); // taza 5 no existe en t (torre vacia)
            fail("Debia lanzar TowerException: taza companiera no esta");
        } catch (TowerException e) {
            assertEquals(TowerException.COMPANION_NOT_IN_TOWER, e.getErrorCode());
        }
    }
    /**
     * FearfulLid: entra si su taza si esta en la torre.
     */
    @Test
    public void testFearfulLidEntersWithCompanion() throws TowerException {
        // tower ya tiene tazas 1-4
        tower.pushLid("fearful", 2);
        assertTrue(tower.ok());
        String[][] lids = tower.placedLids();
        assertEquals(1, lids.length);
        assertEquals("fearful", lids[0][1]);
    }
    /**
     * FearfulLid: no puede salir si esta tapando a su taza.
     */
    @Test
    public void testFearfulLidCannotPopWhenCovering() throws TowerException {
        tower.pushLid("fearful", 2);
        try {
            tower.popLid();
            fail("Debia lanzar TowerException: fearful tapa a su taza");
        } catch (TowerException e) {
            assertEquals(TowerException.CUP_IS_CLOSED, e.getErrorCode());
        }
    }
    /**
     * CrazyLid: se inserta en la BASE de la torre.
     */
    @Test
    public void testCrazyLidGoesToBase() throws TowerException {
        tower.pushLid("crazy", 1);
        String[][] stacking = tower.stackingItems();
        // El primer item (indice 0) debe ser la crazy lid
        assertEquals("lid",   stacking[0][0]);
        assertEquals("crazy", stacking[0][1]);
        assertEquals("1",     stacking[0][2]);
    }
    /**
     * CollapseLid: se agrega correctamente y aparece en stackingItems()
     * con subtipo "collapse".
     */
    @Test
    public void testCollapseLidAppearsInStacking() throws TowerException {
        tower.pushLid("collapse", 1);
        String[][] stacking = tower.stackingItems();
        boolean found = false;
        for (String[] item : stacking) {
            if ("lid".equals(item[0]) && "collapse".equals(item[1]) && "1".equals(item[2])) {
                found = true;
            }
        }
        assertTrue("Debe haber una CollapseLid con numero 1 en la torre", found);
    }

    /**
     * CollapseLid: la operacion pushLid es exitosa (ok() == true).
     */
    @Test
    public void testCollapseLidPushIsOk() throws TowerException {
        tower.pushLid("collapse", 2);
        assertTrue("pushLid con collapse debe reportar ok", tower.ok());
    }

    /**
     * CollapseLid: despues de agregarla la torre mantiene el numero
     * correcto de items (tazas + la tapa collapse).
     */
    @Test
    public void testCollapseLidTowerSizeCorrectAfterPush() throws TowerException {
        int before = tower.stackingItems().length; // 4 tazas
        tower.pushLid("collapse", 1);
        int after = tower.stackingItems().length;
        assertEquals("La torre debe tener un item mas tras pushLid collapse",
            before + 1, after);
    }

    /**
     * CollapseLid: al removerla con popLid la operacion es exitosa
     * y ya no queda en la torre.
     */
    @Test
    public void testCollapseLidPopIsOk() throws TowerException {
        tower.pushLid("collapse", 1);
        tower.popLid();
        assertTrue("popLid de collapse debe reportar ok", tower.ok());
        String[][] stacking = tower.stackingItems();
        boolean collapsePresent = false;
        for (String[] item : stacking) {
            if ("collapse".equals(item[1])) collapsePresent = true;
        }
        assertFalse("No debe quedar CollapseLid en la torre tras popLid", collapsePresent);
    }

    /**
     * CollapseLid: removeLid por posicion logica funciona correctamente.
     */
    @Test
    public void testCollapseLidRemoveByPosition() throws TowerException {
        tower.pushLid("collapse", 1);
        tower.removeLid(0); // unica tapa, posicion 0
        assertTrue("removeLid de collapse debe reportar ok", tower.ok());
        assertEquals("No deben quedar tapas tras remover la CollapseLid",
            0, tower.placedLids().length);
    }

    /**
     * CollapseLid: la logica de la torre (numero de tazas, altura) no
     * cambia por la animacion — solo es un efecto visual.
     */
    @Test
    public void testCollapseLidDoesNotAlterTowerLogic() throws TowerException {
        int heightBefore = tower.height();
        int cupsBefore = 0;
        for (String[] it : tower.stackingItems()) if ("cup".equals(it[0])) cupsBefore++;

        tower.pushLid("collapse", 1);
        tower.popLid();

        int heightAfter = tower.height();
        int cupsAfter = 0;
        for (String[] it : tower.stackingItems()) if ("cup".equals(it[0])) cupsAfter++;

        assertEquals("La altura logica no debe cambiar", heightBefore, heightAfter);
        assertEquals("El numero de tazas no debe cambiar", cupsBefore, cupsAfter);
    }

    /**
     * CollapseLid: placedLids() la registra correctamente mientras esta en la torre.
     */
    @Test
    public void testCollapseLidAppearsInPlacedLids() throws TowerException {
        tower.pushLid("collapse", 3);
        String[][] lids = tower.placedLids();
        boolean found = false;
        for (String[] lid : lids) {
            if ("collapse".equals(lid[1]) && "3".equals(lid[2])) found = true;
        }
        assertTrue("placedLids debe incluir la CollapseLid", found);
    }

    // stackingItems incluye subtipo
    @Test
    public void testStackingItemsIncludesSubtype() throws TowerException {
        tower.pushLid("fearful", 1);
        String[][] stacking = tower.stackingItems();
        boolean fearfulFound = false;
        for (String[] item : stacking) {
            if ("lid".equals(item[0]) && "fearful".equals(item[1])) {
                fearfulFound = true;
            }
        }
        assertTrue("stackingItems debe incluir el subtipo fearful", fearfulFound);
    }

    /**
     * stackingItems incluye subtipo collapse.
     */
    @Test
    public void testStackingItemsIncludesCollapseSubtype() throws TowerException {
        tower.pushLid("collapse", 2);
        String[][] stacking = tower.stackingItems();
        boolean collapseFound = false;
        for (String[] item : stacking) {
            if ("lid".equals(item[0]) && "collapse".equals(item[1])) {
                collapseFound = true;
            }
        }
        assertTrue("stackingItems debe incluir el subtipo collapse", collapseFound);
    }

    // Tower(int) invalido lanza excepcion
    @Test
    public void testConstructorInvalidSize() {
        try {
            new Tower(0);
            fail("Debia lanzar TowerException por tamano invalido");
        } catch (TowerException e) {
            assertEquals(TowerException.INVALID_TOWER_SIZE, e.getErrorCode());
        }
    }

    // reverseTower no rompe pares copa-tapa
    @Test
    public void testReverseTowerKeepsCupLidOrder() throws TowerException {
        tower.pushLid(1);
        tower.reverseTower();
        String[][] stacking = tower.stackingItems();
        int cupIdx = -1, lidIdx = -1;
        for (int i = 0; i < stacking.length; i++) {
            if ("cup".equals(stacking[i][0]) && "1".equals(stacking[i][2])) cupIdx = i;
            if ("lid".equals(stacking[i][0]) && "1".equals(stacking[i][2])) lidIdx = i;
        }
        if (cupIdx >= 0 && lidIdx >= 0) {
            assertTrue("La tapa debe estar despues de su taza", lidIdx > cupIdx);
        }
    }
}