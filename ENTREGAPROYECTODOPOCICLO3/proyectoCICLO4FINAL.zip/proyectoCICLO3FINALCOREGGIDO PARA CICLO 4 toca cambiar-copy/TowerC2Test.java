/**
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
*/

/**
 * Pruebas de unidad para la Torre - Ciclo 2.
 *
 * @author Avila - Bermal
 * @version 2 - Ciclo 2
 */
/**
public class TowerC2Test {
   private Tower tower;
    @BeforeEach
    public void setUp() {
        // Modo invisible: no se llama makeVisible()
        tower = new Tower(300, 100);
    }  
    // Requisitos Funcionales (RF)
    // Tower(int cups) 
    @Test
    public void shouldCreateTowerWithNCups() {
        Tower t = new Tower(4);
        String[][] items = t.stackingItems();
        // Debe haber exactamente 4 tazas
        assertEquals(4, items.length);
        assertTrue(t.ok());
    }
    @Test
    public void shouldCreateTowerWithCupsInDescendingOrder() {
        Tower t = new Tower(3);
        String[][] items = t.stackingItems();
        // Base debe ser la taza más grande (3), cima la más pequeña (1)
        assertEquals("cup", items[0][0]);
        assertEquals("3", items[0][1]);
        assertEquals("1", items[2][1]);
    }
    @Test
    public void shouldNotCreateTowerWithZeroCups() {
        Tower t = new Tower(0);
        // ok() debe ser false
        assertFalse(t.ok());
    }
    @Test
    public void shouldCreateTowerWithNoCupsButLids() {
        // Torre vacía: no hay tazas
        assertEquals(0, tower.stackingItems().length);
    }
    // pushCup / popCup / removeCup 
    @Test
    public void shouldPushCupToTower() {
        tower.pushCup(1);
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }
    @Test
    public void shouldNotPushCupWithInvalidNumber() {
        tower.pushCup(0);
        assertFalse(tower.ok());
    }
    @Test
    public void shouldPopLastCup() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.popCup();
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }
    @Test
    public void shouldNotPopCupFromEmptyTower() {
        tower.popCup();
        assertFalse(tower.ok());
    }
    @Test
    public void shouldRemoveCupAtIndex() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushCup(3);
        tower.removeCup(1); // eliminar la segunda taza
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
    }
    @Test
    public void shouldNotRemoveCupAtInvalidIndex() {
        tower.pushCup(1);
        tower.removeCup(5);
        assertFalse(tower.ok());
    }
    // pushLid / popLid / removeLid 
    @Test
    public void shouldPushLidToTower() {
        tower.pushLid(1);
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }
    @Test
    public void shouldNotPushLidWithInvalidNumber() {
        tower.pushLid(-1);
        assertFalse(tower.ok());
    }
    @Test
    public void shouldPopLastLid() {
        tower.pushLid(1);
        tower.pushLid(2);
        tower.popLid();
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }
    @Test
    public void shouldNotPopLidFromEmptyTower() {
        tower.popLid();
        assertFalse(tower.ok());
    }
    //  height() 
    @Test
    public void shouldReturnCorrectHeight() {
        tower.pushCup(1); 
        tower.pushCup(2); 
        tower.pushLid(1); 
        assertEquals(3, tower.height()); // lid1 cabe dentro de cup2
    }
    @Test
    public void shouldReturnZeroHeightForEmptyTower() {
        assertEquals(0, tower.height());
    }
    // lidedCups() 
    @Test
    public void shouldReturnLidedCups() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1); // tapa de la taza 1
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(1, lided[0]);
    }
    @Test
    public void shouldReturnEmptyLidedCupsWhenNoLids() {
        tower.pushCup(1);
        assertEquals(0, tower.lidedCups().length);
    }
    // stackingItems() 
    @Test
    public void shouldReturnAllItemsInOrder() {
        tower.pushCup(2);
        tower.pushLid(2);
        String[][] items = tower.stackingItems();
        assertEquals("cup", items[0][0]);
        assertEquals("2", items[0][1]);
        assertEquals("lid", items[1][0]);
        assertEquals("2", items[1][1]);
    }
    // RF11: swap() 
    @Test
    public void shouldSwapTwoItems() {
        tower.pushCup(1);
        tower.pushCup(2);
        String[] id1 = {"cup", "1"};
        String[] id2 = {"cup", "2"};
        tower.swap(id1, id2);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        assertEquals("2", items[0][1]); 
    }
    @Test
    public void shouldNotSwapNonExistentItem() {
        tower.pushCup(1);
        String[] id1 = {"cup", "1"};
        String[] id2 = {"cup", "99"};
        tower.swap(id1, id2);
        assertFalse(tower.ok());
    }
    @Test
    public void shouldSwapCupAndLid() {
        tower.pushCup(1);
        tower.pushLid(2);
        String[] idCup = {"cup", "1"};
        String[] idLid = {"lid", "2"};
        tower.swap(idCup, idLid);
        assertTrue(tower.ok());
        // La tapa ahora está en la base
        assertEquals("lid", tower.stackingItems()[0][0]);
    }
    // cover() 
    @Test
    public void shouldCoverCupWhenLidPresent() {
        tower.pushCup(1);
        tower.pushLid(1);
        tower.cover();
        assertTrue(tower.ok());
        // La taza 1 debe estar cubierta
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
    }
    @Test
    public void shouldNotCoverCupWithoutLid() {
        tower.pushCup(1);
        tower.cover();
        assertTrue(tower.ok());
        // No hay tazas cubiertas
        assertEquals(0, tower.lidedCups().length);
    }
    @Test
    public void shouldNotCoverCupIfLidIsForDifferentCup() {
        tower.pushCup(1);
        tower.pushLid(2); // tapa de taza 2, no de taza 1
        tower.cover();
        // Taza 1 no debe estar cubierta
        assertEquals(0, tower.lidedCups().length);
    }
    // swapToReduce() 
    @Test
    public void shouldReturnNullWhenNoSwapReducesHeight() {
        // Una sola taza: no hay swap posible
        tower.pushCup(1);
        String[][] result = tower.swapToReduce();
        assertNull(result);
        assertTrue(tower.ok());
    }
    @Test
    public void shouldFindSwapThatReducesHeight() {
        // Taza grande arriba, taza pequeña abajo puede reducir
        // Estructura que reduce al invertir:
        tower.pushCup(1); 
        tower.pushLid(1); 
        tower.pushCup(4);  
        // Simplemente verifica que el método retorna algo o null sin lanzar excepción
        String[][] result = tower.swapToReduce();
        assertTrue(tower.ok());
        // Si retorna algo debe tener dos identificadores
        if (result != null) {
            assertEquals(2, result.length);
            assertTrue(result[0].length >= 2);
            assertTrue(result[1].length >= 2);
        }
    }
    // orderTower() / reverseTower() 
    @Test
    public void shouldOrderTowerDescending() {
        tower.pushCup(1); // 
        tower.pushCup(3); // 
        tower.pushCup(2); // 
        tower.orderTower();
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        // La base debe ser la taza más grande
        assertEquals("3", items[0][1]);
    }
    @Test
    public void shouldReverseTower() {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.reverseTower();
        assertTrue(tower.ok());
        // cup2 ahora está en la base
        assertEquals("2", tower.stackingItems()[0][1]);
    }
    // ok() 
    @Test
    public void shouldReturnTrueAfterSuccessfulOperation() {
        tower.pushCup(1);
        assertTrue(tower.ok());
    }
    @Test
    public void shouldReturnFalseAfterFailedOperation() {
        tower.popCup(); // torre vacía
        assertFalse(tower.ok());
    }
}
*/

