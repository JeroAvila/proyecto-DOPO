import shapes.*;
import java.util.ArrayList;

/**
 * Modela la torre del simulador Stacking Cups.
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class Tower {

    private static final int CANVAS_BASE_Y   = 520;
    private static final int CANVAS_CENTER_X = 250;
    private static final String[] PALETTE = {
        "blue", "green", "red", "yellow", "orange", "magenta", "black", "white"
    };

    private ArrayList<StackableItem> items;
    private int canvasWidth;
    private int maxHeightCm;
    private boolean isDisplayed;
    private boolean lastOpOk;
    private ArrayList<Rectangle> scaleMarks;

    //  Constructores

    /**
     * Torre vacia con dimensiones dadas.
     * @param canvasWidth ancho del canvas en px
     * @param maxHeightCm altura maxima en cm
     */
    public Tower(int canvasWidth, int maxHeightCm) {
        this.canvasWidth  = canvasWidth;
        this.maxHeightCm  = maxHeightCm;
        this.isDisplayed  = false;
        this.lastOpOk     = true;
        this.items        = new ArrayList<StackableItem>();
        this.scaleMarks   = new ArrayList<Rectangle>();
    }
    /**
     * Crea una torre con N tazas normales (mayor en la base, menor en la cima).
     * @param numberOfCups cantidad de tazas (>= 1)
     * @throws TowerException si numberOfCups < 1
     */
    public Tower(int numberOfCups) throws TowerException {
        this(500, 300);
        if (numberOfCups < 1) {
            lastOpOk = false;
            throw new TowerException(TowerException.INVALID_TOWER_SIZE,
                "La torre debe tener al menos 1 taza, recibido: " + numberOfCups);
        }
        for (int i = numberOfCups; i >= 1; i--) {
            items.add(new Cup(i, colorForNumber(i)));
        }
        lastOpOk = true;
    }
    // Visibilidad 
    /** Hace visible la torre (incluso si esta vacia, muestra el canvas). */
    public void makeVisible() {
        if (isDisplayed) return;
        isDisplayed = true;
        Canvas.getCanvas();   // abre/muestra la ventana aunque no haya items
        repositionAll();
        for (StackableItem item : items) item.makeVisible();
        buildScaleRule();
    }
    /** Hace invisible la torre. */
    public void makeInvisible() {
        if (!isDisplayed) return;
        for (StackableItem item : items) item.makeInvisible();
        hideScaleRule();
        isDisplayed = false;
    }
    // Gestion de tazas
    /**
     * Agrega una taza NORMAL a la cima.
     * @param cupNumber numero de la taza (>= 1)
     * @throws TowerException si cupNumber < 1
     */
    public void pushCup(int cupNumber) throws TowerException {
        pushCup("normal", cupNumber);
    }
    /**
     * Agrega una taza del tipo indicado.
     * Tipos: "normal", "opener", "hierarchical".
     *
     * @param type      subtipo de taza
     * @param cupNumber numero de la taza (>= 1)
     * @throws TowerException si cupNumber < 1
     */
    public void pushCup(String type, int cupNumber) throws TowerException {
        if (cupNumber < 1) {
            lastOpOk = false;
            showError("El numero de taza debe ser >= 1, recibido: " + cupNumber);
            throw new TowerException(TowerException.INVALID_NUMBER,
                "El numero de taza debe ser >= 1, recibido: " + cupNumber);
        }
        StackableItem newCup;
        switch (type.toLowerCase()) {
            case "opener":
                newCup = new OpenerCup(cupNumber, colorForNumber(cupNumber));
                removeBlockingLids(cupNumber);
                break;
            case "hierarchical":
                newCup = new HierarchicalCup(cupNumber, colorForNumber(cupNumber));
                break;
            default:
                newCup = new Cup(cupNumber, colorForNumber(cupNumber));
                break;
        }
        items.add(newCup);
        if ("hierarchical".equals(newCup.getSubtype())) {
            pushDownHierarchical(newCup);
        }
        if (isDisplayed) {
            repositionAll();
            for (StackableItem item : items) item.makeVisible();
            rebuildScale();
        }
        lastOpOk = true;
    }
    /**
     * Quita la ultima taza de la torre.
     * @throws TowerException si no hay tazas o la taza esta anclada
     */
    public void popCup() throws TowerException {
        int idx = lastIndexOfType("cup");
        if (idx < 0) {
            lastOpOk = false;
            showError("No hay tazas en la torre");
            throw new TowerException(TowerException.NO_CUPS, "No hay tazas en la torre");
        }
        StackableItem cup = items.get(idx);
        if (cup instanceof HierarchicalCup && ((HierarchicalCup) cup).isAnchored()) {
            lastOpOk = false;
            showError("La taza hierarchical anclada no puede removerse");
            throw new TowerException(TowerException.CUP_IS_CLOSED,
                "La taza hierarchical anclada no puede removerse");
        }
        items.remove(idx).makeInvisible();
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Elimina la taza en la posicion logica indicada (0 = primera desde la base).
     *
     * CORRECCION: posicion invalida lanza OUT_OF_BOUNDS con mensaje visible.
     *
     * @param position posicion logica (0-based)
     * @throws TowerException si la posicion no existe o la taza esta anclada
     */
    public void removeCup(int position) throws TowerException {
        int real = realIndexOfNthOfType("cup", position);
        if (real < 0) {
            lastOpOk = false;
            showError("No existe taza en la posicion " + position
                + ". La copa pudo haber salido del tablero o la posicion es invalida.");
            throw new TowerException(TowerException.OUT_OF_BOUNDS,
                "No existe taza en la posicion " + position);
        }
        StackableItem cup = items.get(real);
        if (cup instanceof HierarchicalCup && ((HierarchicalCup) cup).isAnchored()) {
            lastOpOk = false;
            showError("La taza hierarchical anclada al fondo no puede removerse");
            throw new TowerException(TowerException.CUP_IS_CLOSED,
                "La taza hierarchical anclada al fondo no puede removerse");
        }
        items.remove(real).makeInvisible();
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    //  Gestion de tapas
    /**
     * Agrega una tapa NORMAL a la cima.
     *
     * CORRECCION: la tapa se hace visible INMEDIATAMENTE al colocarla.
     *
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @throws TowerException si cupNumber < 1
     */
    public void pushLid(int cupNumber) throws TowerException {
        pushLid("normal", cupNumber);
    }
    /**
     * Agrega una tapa del tipo indicado.
     */
    public void pushLid(String type, int cupNumber) throws TowerException {
        if (cupNumber < 1) {
            lastOpOk = false;
            showError("El numero de tapa debe ser >= 1, recibido: " + cupNumber);
            throw new TowerException(TowerException.INVALID_NUMBER,
                "El numero de tapa debe ser >= 1, recibido: " + cupNumber);
        }

        if ("fearful".equalsIgnoreCase(type)) {
            if (findItemByTypeAndNumber("cup", cupNumber) == null) {
                lastOpOk = false;
                showError("La tapa fearful " + cupNumber
                    + " no puede entrar: su taza companiera no esta en la torre");
                throw new TowerException(TowerException.COMPANION_NOT_IN_TOWER,
                    "La taza companiera " + cupNumber + " no esta en la torre");
            }
        }
        StackableItem newLid;
        switch (type.toLowerCase()) {
            case "fearful":  newLid = new FearfulLid(cupNumber, colorForNumber(cupNumber));  break;
            case "crazy":    newLid = new CrazyLid(cupNumber, colorForNumber(cupNumber));    break;
            case "collapse": newLid = new CollapseLid(cupNumber, colorForNumber(cupNumber)); break;
            default:         newLid = new Lid(cupNumber, colorForNumber(cupNumber));          break;
        }
        // CrazyLid va a la base; el resto a la cima
        if ("crazy".equals(newLid.getSubtype())) {
            items.add(0, newLid);
        } else {
            items.add(newLid);
        }
        // CORRECCION: visible inmediatamente
        if (isDisplayed) {
            repositionAll();
            for (StackableItem item : items) item.makeVisible();
            rebuildScale();
        }
        // CollapseLid: animar derrumbe al entrar
        if ("collapse".equals(newLid.getSubtype()) && isDisplayed) {
            animateCollapse();
        }
        lastOpOk = true;
    }
    /**
     * Quita la ultima tapa de la torre.
     */
    public void popLid() throws TowerException {
        int idx = lastIndexOfType("lid");
        if (idx < 0) {
            lastOpOk = false;
            showError("No hay tapas en la torre");
            throw new TowerException(TowerException.NO_LIDS, "No hay tapas en la torre");
        }
        StackableItem lid = items.get(idx);
        if ("fearful".equals(lid.getSubtype()) && isCoveringItsCup(lid)) {
            lastOpOk = false;
            showError("La tapa fearful " + lid.getItemNumber()
                + " esta tapando a su taza y no puede salir");
            throw new TowerException(TowerException.CUP_IS_CLOSED,
                "La tapa fearful esta tapando a su taza y no puede salir");
        }
        StackableItem removed = items.remove(idx);
        if ("collapse".equals(removed.getSubtype()) && isDisplayed) {
            animateCollapse();
        }
        removed.makeInvisible();
        uncoverMatchingCup(removed.getItemNumber());
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    /**
     * Elimina la tapa en la posicion logica indicada
     */
    public void removeLid(int position) throws TowerException {
        int real = realIndexOfNthOfType("lid", position);
        if (real < 0) {
            lastOpOk = false;
            showError("No existe tapa en la posicion " + position
                + ". Posicion invalida o la tapa no esta en la torre.");
            throw new TowerException(TowerException.OUT_OF_BOUNDS,
                "No existe tapa en la posicion " + position);
        }
        StackableItem lid = items.get(real);
        if ("fearful".equals(lid.getSubtype()) && isCoveringItsCup(lid)) {
            lastOpOk = false;
            showError("La tapa fearful " + lid.getItemNumber()
                + " esta tapando a su taza y no puede removerse");
            throw new TowerException(TowerException.CUP_IS_CLOSED,
                "La tapa fearful esta tapando a su taza y no puede removerse");
        }
        StackableItem removed = items.remove(real);
        if ("collapse".equals(removed.getSubtype()) && isDisplayed) {
            animateCollapse();
        }
        removed.makeInvisible();
        uncoverMatchingCup(removed.getItemNumber());
        if (isDisplayed) { repositionAll(); rebuildScale(); }
        lastOpOk = true;
    }
    // Reorganizacion
    /**
     * Ordena las tazas de mayor a menor altura logica.
     *
     * CORRECCION: no rompe pares copa-tapa; el par se mueve junto.
     */
    public void orderTower() {
        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();
        sortItemsByHeightDescending();
        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
    /**
     * Invierte el orden de todos los items.
     * CORRECCION: las tapas se muestran en posicion correcta inmediatamente.
     */
    public void reverseTower() {
        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();
        java.util.Collections.reverse(items);
        // Post-correccion: tapa que quedo antes de su taza -> moverla despues
        for (int i = 0; i < items.size(); i++) {
            if (!items.get(i).isContainer()) continue;
            int cupNumber = items.get(i).getItemNumber();
            for (int j = 0; j < i; j++) {
                if (!items.get(j).isContainer()
                        && items.get(j).getItemNumber() == cupNumber) {
                    StackableItem misplaced = items.remove(j);
                    items.add(i, misplaced);
                    break;
                }
            }
        }
        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
    /**
     * Intercambia dos items por tipo y numero.
     * CORRECCION: muestra dialogo si algun item no se encuentra.
     */
    public void swap(String type1, int n1, String type2, int n2) throws TowerException {
        swap(new String[]{ type1, String.valueOf(n1) },
             new String[]{ type2, String.valueOf(n2) });
    }
    public void swap(String[] id1, String[] id2) throws TowerException {
        int i1 = findItemIndex(id1);
        int i2 = findItemIndex(id2);
        if (i1 < 0 || i2 < 0) {
            lastOpOk = false;
            showError("Item no encontrado para swap");
            throw new TowerException(TowerException.ITEM_NOT_FOUND,
                "Item no encontrado para swap");
        }
        boolean wasVisible = isDisplayed;
        if (wasVisible) makeInvisible();
        StackableItem tmp = items.get(i1);
        items.set(i1, items.get(i2));
        items.set(i2, tmp);
        if (wasVisible) makeVisible();
        lastOpOk = true;
    }
    /**
     * Tapa todas las tazas que tienen su tapa en la torre.
     * CORRECCION: no afecta el orden interno; pushLid() funciona bien despues.
     */
    public void cover() {
        for (StackableItem item : items) item.notifyCover(false);
        for (StackableItem lid : items) {
            if (!lid.isContainer() && "lid".equals(lid.getItemType())) {
                StackableItem cup = findItemByTypeAndNumber("cup", lid.getItemNumber());
                if (cup != null) cup.notifyCover(true);
            }
        }
        lastOpOk = true;
    }
    //  Consultas 
    /** Altura total de la torre en cm considerando anidamiento. */
    public int height() {
        java.util.Stack<Integer> containerInteriors = new java.util.Stack<Integer>();
        int total = 0;
        for (StackableItem item : items) {
            int w = item.getWidthPixels();
            while (!containerInteriors.isEmpty() && w >= containerInteriors.peek())
                containerInteriors.pop();
            if (containerInteriors.isEmpty()) {
                total += item.getHeightCm();
                if (item.isContainer()) containerInteriors.push(item.getInteriorWidth());
            } else {
                if (item.isContainer()) containerInteriors.push(item.getInteriorWidth());
            }
        }
        return total;
    }
    /** Numeros de las tazas que tienen su tapa en la torre. */
    public int[] lidedCups() {
        ArrayList<Integer> result = new ArrayList<Integer>();
        for (StackableItem item : items) {
            if ("lid".equals(item.getItemType())
                    && findItemByTypeAndNumber("cup", item.getItemNumber()) != null) {
                result.add(item.getItemNumber());
            }
        }
        int[] out = new int[result.size()];
        for (int i = 0; i < out.length; i++) out[i] = result.get(i);
        return out;
    }
    /**
     * CICLO 4 Lista de tapas que ya han sido colocadas en la torre.
     * @return arreglo con cada tapa presente en la torre
     */
    public String[][] placedLids() {
        ArrayList<String[]> result = new ArrayList<String[]>();
        for (StackableItem item : items) {
            if ("lid".equals(item.getItemType())) {
                result.add(new String[]{
                    item.getItemType(),
                    item.getSubtype(),
                    String.valueOf(item.getItemNumber())
                });
            }
        }
        return result.toArray(new String[0][]);
    }
    /**
     * Todos los items como matriz de strings.
     */
    public String[][] stackingItems() {
        String[][] result = new String[items.size()][3];
        for (int i = 0; i < items.size(); i++) {
            result[i][0] = items.get(i).getItemType();
            result[i][1] = items.get(i).getSubtype();
            result[i][2] = String.valueOf(items.get(i).getItemNumber());
        }
        return result;
    }
    /** Primer swap que reduce la altura, o null si no hay mejora. */
    public String[][] swapToReduce() {
        int currentHeight = height();
        for (int i = 0; i < items.size() - 1; i++) {
            for (int j = i + 1; j < items.size(); j++) {
                StackableItem tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);
                int newHeight = height();
                tmp = items.get(i);
                items.set(i, items.get(j));
                items.set(j, tmp);
                if (newHeight < currentHeight) {
                    lastOpOk = true;
                    return new String[][]{ toIdentifier(items.get(i)), toIdentifier(items.get(j)) };
                }
            }
        }
        lastOpOk = true;
        return null;
    }
    /**
     * Voltea la torre: todos los items se ocultan y la torre queda vacia.
     * @throws TowerException si la torre ya estaba vacia
     */
    public void tilt() throws TowerException {
        if (items.isEmpty()) {
            lastOpOk = false;
            showError("No se puede inclinar una torre vacia");
            throw new TowerException(TowerException.EMPTY_TOWER,
                "No se puede inclinar una torre vacia");
        }
        makeInvisible();
        items.clear();
        lastOpOk = true;
    }
    /** Cierra el simulador. */
    public void exit() {
        makeInvisible();
        items.clear();
        lastOpOk = true;
    }
    /** @return true si la ultima operacion fue exitosa. */
    public boolean ok() { return lastOpOk; }
    // Logica interna de tipos (privado) 
    /** Elimina tapas con numero <= cupNumber (usado por OpenerCup). */
    private void removeBlockingLids(int cupNumber) {
        for (int i = items.size() - 1; i >= 0; i--) {
            StackableItem item = items.get(i);
            if ("lid".equals(item.getItemType()) && item.getItemNumber() <= cupNumber) {
                items.remove(i).makeInvisible();
            }
        }
    }
    /** Desplaza HierarchicalCup hacia la base pasando items menores; la ancla si llega al fondo. */
    private void pushDownHierarchical(StackableItem hCup) {
        int idx = items.indexOf(hCup);
        if (idx < 0) return;
        while (idx > 0) {
            StackableItem below = items.get(idx - 1);
            if (below.getWidthPixels() < hCup.getWidthPixels()) {
                items.set(idx, below);
                items.set(idx - 1, hCup);
                idx--;
            } else break;
        }
        if (idx == 0 && hCup instanceof HierarchicalCup)
            ((HierarchicalCup) hCup).setAnchored(true);
    }
    /** True si la tapa esta despues de su taza en la lista (la esta cubriendo). */
    private boolean isCoveringItsCup(StackableItem lid) {
        int lidIdx = items.indexOf(lid);
        if (lidIdx < 0) return false;
        for (int i = 0; i < lidIdx; i++) {
            StackableItem c = items.get(i);
            if ("cup".equals(c.getItemType()) && c.getItemNumber() == lid.getItemNumber())
                return true;
        }
        return false;
    }
    /**
     * Anima el derrumbe de la torre: cada item cae al fondo del canvas
     * en cascada y luego todos regresan a su posicion correcta.
     * La logica interna de la torre NO se modifica, solo la posicion visual.
     */
    private void animateCollapse() {
        if (!isDisplayed || items.isEmpty()) return;
        int n = items.size();
        int[] origX = new int[n];
        int[] origY = new int[n];

        // Calcular posiciones actuales de cada item
        java.util.Stack<int[]> ct = new java.util.Stack<int[]>();
        int topY = CANVAS_BASE_Y;
        for (int i = 0; i < n; i++) {
            StackableItem it = items.get(i);
            int w = it.getWidthPixels(), h = it.getHeightPixels();
            while (!ct.isEmpty() && w >= ct.peek()[0]) ct.pop();
            int iy;
            if (ct.isEmpty()) { iy = topY - h; topY = iy; }
            else              { iy = ct.peek()[1] - h; }
            origX[i] = CANVAS_CENTER_X - w / 2;
            origY[i] = iy;
            if (it.isContainer()) ct.push(new int[]{ it.getInteriorWidth(), iy + it.getInteriorFloorOffset() });
        }

        int step    = CollapseLid.FALL_STEP_PX;
        int delay   = CollapseLid.FRAME_DELAY_MS;
        int iDelay  = CollapseLid.ITEM_DELAY_MS / delay + 1;
        int floor   = CollapseLid.FLOOR_Y;
        int[] curY  = origY.clone();

        // FASE 1: caida en cascada, de abajo hacia arriba
        for (int frame = 0; frame < 120; frame++) {
            boolean moving = false;
            for (int i = n - 1; i >= 0; i--) {
                if (frame < (n - 1 - i) * iDelay) continue;
                int target = floor - items.get(i).getHeightPixels();
                if (curY[i] < target) {
                    curY[i] = Math.min(curY[i] + step, target);
                    items.get(i).moveTo(origX[i], curY[i]);
                    moving = true;
                }
            }
            try { Thread.sleep(delay); } catch (InterruptedException e) { break; }
            if (!moving) break;
        }

        // Pausa en el fondo
        try { Thread.sleep(250); } catch (InterruptedException ignored) {}

        // FASE 2: todos suben de vuelta a la vez
        boolean rising = true;
        while (rising) {
            rising = false;
            for (int i = 0; i < n; i++) {
                if (curY[i] > origY[i]) {
                    curY[i] = Math.max(curY[i] - step, origY[i]);
                    items.get(i).moveTo(origX[i], curY[i]);
                    rising = true;
                }
            }
            try { Thread.sleep(delay); } catch (InterruptedException e) { break; }
        }

        repositionAll();
    }

    //  Posicionamiento visual
    private void repositionAll() {
        java.util.Stack<int[]> containers = new java.util.Stack<int[]>();
        int towerTopY = CANVAS_BASE_Y;
        for (StackableItem item : items) {
            int w = item.getWidthPixels(), hPx = item.getHeightPixels();
            while (!containers.isEmpty() && w >= containers.peek()[0]) containers.pop();
            int itemTopY;
            if (containers.isEmpty()) {
                itemTopY  = towerTopY - hPx;
                towerTopY = itemTopY;
            } else {
                itemTopY = containers.peek()[1] - hPx;
            }
            item.moveTo(CANVAS_CENTER_X - w / 2, itemTopY);
            if (item.isContainer())
                containers.push(new int[]{ item.getInteriorWidth(),
                                           itemTopY + item.getInteriorFloorOffset() });
        }
    }
    //  Ordenamiento
    /**
     * Ordena por heightCm descendente.
     * CORRECCION: mueve pares copa-tapa juntos para no romper relaciones.
     */
    private void sortItemsByHeightDescending() {
        ArrayList<StackableItem> cups = new ArrayList<StackableItem>();
        ArrayList<StackableItem> lids = new ArrayList<StackableItem>();
        for (StackableItem item : items) {
            if (item.isContainer()) cups.add(item);
            else                    lids.add(item);
        }
        for (int i = 0; i < cups.size() - 1; i++)
            for (int j = 0; j < cups.size() - i - 1; j++)
                if (cups.get(j).getHeightCm() < cups.get(j + 1).getHeightCm()) {
                    StackableItem tmp = cups.get(j);
                    cups.set(j, cups.get(j + 1));
                    cups.set(j + 1, tmp);
                }
        items.clear();
        ArrayList<StackableItem> usedLids = new ArrayList<StackableItem>();
        for (StackableItem cup : cups) {
            items.add(cup);
            for (StackableItem lid : lids) {
                if (!usedLids.contains(lid) && lid.getItemNumber() == cup.getItemNumber()) {
                    items.add(lid);
                    usedLids.add(lid);
                    break;
                }
            }
        }
        for (StackableItem lid : lids)
            if (!usedLids.contains(lid)) items.add(lid);
    }
    //  Auxiliares de busqueda 
    private int findItemIndex(String[] id) {
        if (id == null || id.length < 2) return -1;
        String type = id[0];
        int    num  = Integer.parseInt(id[1]);
        for (int i = 0; i < items.size(); i++) {
            StackableItem item = items.get(i);
            if (type.equals(item.getItemType()) && num == item.getItemNumber()) return i;
        }
        return -1;
    }
    private StackableItem findItemByTypeAndNumber(String type, int number) {
        for (StackableItem item : items)
            if (type.equals(item.getItemType()) && number == item.getItemNumber()) return item;
        return null;
    }
    private int lastIndexOfType(String type) {
        for (int i = items.size() - 1; i >= 0; i--)
            if (type.equals(items.get(i).getItemType())) return i;
        return -1;
    }
    private int realIndexOfNthOfType(String type, int n) {
        if (n < 0) return -1;
        int count = 0;
        for (int i = 0; i < items.size(); i++) {
            if (type.equals(items.get(i).getItemType())) {
                if (count == n) return i;
                count++;
            }
        }
        return -1;
    }
    private void uncoverMatchingCup(int cupNumber) {
        StackableItem cup = findItemByTypeAndNumber("cup", cupNumber);
        if (cup != null) cup.notifyCover(false);
    }
    private String[] toIdentifier(StackableItem item) {
        return new String[]{ item.getItemType(), String.valueOf(item.getItemNumber()) };
    }
    //  Regla lateral 
    private void buildScaleRule() {
        if (!isDisplayed) return;
        int totalCm = height();
        if (totalCm == 0) return;
        for (int cm = 0; cm <= totalCm; cm++) {
            int tickY = CANVAS_BASE_Y - (cm * Cup.PIXELS_PER_CM) - 1;
            boolean major = (cm % 5 == 0);
            int len = major ? 12 : 6;
            Rectangle tick = new Rectangle();
            tick.changeColor("black");
            tick.changeSize(2, len);
            tick.moveHorizontal((32 - len) - 70);
            tick.moveVertical(tickY - 15);
            tick.makeVisible();
            scaleMarks.add(tick);
        }
    }
    private void hideScaleRule() {
        for (Rectangle r : scaleMarks) r.makeInvisible();
        scaleMarks.clear();
    }
    private void rebuildScale() {
        if (isDisplayed) { hideScaleRule(); buildScaleRule(); }
    }
    // Dialogo de error
    /**
     * CORRECCION CICLO 4: toda operacion fallida muestra este dialogo.
     * El usuario siempre ve el error, no solo en consola.
     */
    private void showError(String msg) {
        javax.swing.JOptionPane.showMessageDialog(
            null, "ERROR: " + msg, "Error en la Torre",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
    private String colorForNumber(int n) {
        return PALETTE[(n - 1) % PALETTE.length];
    }
}