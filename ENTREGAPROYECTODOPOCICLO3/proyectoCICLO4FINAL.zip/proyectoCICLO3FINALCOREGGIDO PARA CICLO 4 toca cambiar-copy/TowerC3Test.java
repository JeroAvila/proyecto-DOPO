import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pruebas de unidad para la Torre - Ciclo 3.
 *
 * CICLO 3 
 * Se prueba que los métodos lanzan TowerException
 * con el código de error correcto, en lugar de solo retornar ok()=false.
 *
 * @author Avila - Bernal
 * @version 1 - Ciclo 3
 */
public class TowerC3Test {
    //atributos
    private Tower tower;

    @BeforeEach
    public void setUp() {
        tower = new Tower(500, 300);
    }
    // Tower(int numberOfCups) con excepción
    @Test
    public void shouldThrowExceptionWhenCreatingTowerWithZeroCups() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            new Tower(0);
        });
        assertEquals(TowerException.INVALID_TOWER_SIZE, ex.getErrorCode());
    }
    @Test
    public void shouldThrowExceptionWhenCreatingTowerWithNegativeCups() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            new Tower(-3);
        });
        assertEquals(TowerException.INVALID_TOWER_SIZE, ex.getErrorCode());
    }
    @Test
    public void shouldCreateTowerWithOneCupWithoutException() throws TowerException {
        Tower t = new Tower(1);
        assertTrue(t.ok());
        assertEquals(1, t.stackingItems().length);
    }
    // pushCup con excepción
    @Test
    public void shouldThrowExceptionWhenPushingCupWithZeroNumber() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.pushCup(0);
        });
        assertEquals(TowerException.INVALID_NUMBER, ex.getErrorCode());
    }
    @Test
    public void shouldThrowExceptionWhenPushingCupWithNegativeNumber() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.pushCup(-5);
        });
        assertEquals(TowerException.INVALID_NUMBER, ex.getErrorCode());
    }
    @Test
    public void shouldPushValidCupWithoutException() throws TowerException {
        tower.pushCup(2);
        assertTrue(tower.ok());
        assertEquals(1, tower.stackingItems().length);
    }
    // popCup con excepción
    @Test
    public void shouldThrowExceptionWhenPoppingCupFromEmptyTower() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.popCup();
        });
        assertEquals(TowerException.NO_CUPS, ex.getErrorCode());
    }
    @Test
    public void shouldThrowExceptionWhenPoppingCupFromTowerWithOnlyLids()
            throws TowerException {
        tower.pushLid(1); // solo hay una tapa, no tazas
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.popCup();
        });
        assertEquals(TowerException.NO_CUPS, ex.getErrorCode());
    }
    @Test
    public void shouldPopCupWithoutException() throws TowerException {
        tower.pushCup(1);
        tower.popCup();
        assertTrue(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }
    // removeCup con excepción
    @Test
    public void shouldThrowExceptionWhenRemovingCupAtInvalidPosition()
            throws TowerException {
        tower.pushCup(1);
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.removeCup(5); // posición 5 no existe
        });
        assertEquals(TowerException.INVALID_CUP_POSITION, ex.getErrorCode());
    }
    @Test
    public void shouldRemoveCupAtValidPositionWithoutException() throws TowerException {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushCup(3);
        tower.removeCup(1); // posición 1 (la segunda taza)
        assertTrue(tower.ok());
        assertEquals(2, tower.stackingItems().length);
    }
    // pushLid con excepción
    @Test
    public void shouldThrowExceptionWhenPushingLidWithNegativeNumber() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.pushLid(-1);
        });
        assertEquals(TowerException.INVALID_NUMBER, ex.getErrorCode());
    }
    @Test
    public void shouldPushValidLidWithoutException() throws TowerException {
        tower.pushLid(2);
        assertTrue(tower.ok());
    }
    // popLid con excepción
    @Test
    public void shouldThrowExceptionWhenPoppingLidFromEmptyTower() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.popLid();
        });
        assertEquals(TowerException.NO_LIDS, ex.getErrorCode());
    }
    @Test
    public void shouldThrowExceptionWhenPoppingLidFromTowerWithOnlyCups()
            throws TowerException {
        tower.pushCup(1);
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.popLid();
        });
        assertEquals(TowerException.NO_LIDS, ex.getErrorCode());
    }
    @Test
    public void shouldPopLidWithoutException() throws TowerException {
        tower.pushLid(1);
        tower.popLid();
        assertTrue(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }
    // removeLid con excepción
    @Test
    public void shouldThrowExceptionWhenRemovingLidAtInvalidPosition()
            throws TowerException {
        tower.pushLid(1);
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.removeLid(10);
        });
        assertEquals(TowerException.INVALID_LID_POSITION, ex.getErrorCode());
    }
    // swap con excepción
    @Test
    public void shouldThrowExceptionWhenSwappingNonExistentItem()
            throws TowerException {
        tower.pushCup(1);
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.swap("cup", 1, "cup", 99); // cup 99 no existe
        });
        assertEquals(TowerException.ITEM_NOT_FOUND, ex.getErrorCode());
    }
    @Test
    public void shouldSwapExistingItemsWithoutException() throws TowerException {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.swap("cup", 1, "cup", 2);
        assertTrue(tower.ok());
        // Cup2 ahora está en la base
        assertEquals("2", tower.stackingItems()[0][1]);
    }
    // tilt() metodo Ciclo 3
    @Test
    public void shouldTiltTowerAndLeaveItEmpty() throws TowerException {
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);
        tower.tilt();
        assertTrue(tower.ok());
        assertEquals(0, tower.stackingItems().length);
    }
    @Test
    public void shouldThrowExceptionWhenTiltingEmptyTower() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.tilt();
        });
        assertEquals(TowerException.EMPTY_TOWER, ex.getErrorCode());
    }
    @Test
    public void shouldThrowCorrectErrorMessageWhenTiltingEmptyTower() {
        TowerException ex = assertThrows(TowerException.class, () -> {
            tower.tilt();
        });
        assertNotNull(ex.getMessage());
        assertFalse(ex.getMessage().isEmpty());
    }
    // ok() sigue funcionando tras excepciones
    @Test
    public void okShouldBeFalseAfterException() {
        try {
            tower.popCup();
        } catch (TowerException e) {
            // esperado
        }
        assertFalse(tower.ok());
    }
    @Test
    public void okShouldBeTrueAfterSuccessfulOperationFollowingException()
            throws TowerException {
        try {
            tower.popCup(); // falla
        } catch (TowerException e) {
            // esperado, ok=false
        }
        tower.pushCup(1); // operación exitosa
        assertTrue(tower.ok());
    }
}
