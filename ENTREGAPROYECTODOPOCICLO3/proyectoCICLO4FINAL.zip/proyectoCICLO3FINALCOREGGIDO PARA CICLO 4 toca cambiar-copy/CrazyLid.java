/**
 * Tapa crazy
 * En lugar de ubicarse en la cima, se inserta en la base de la torre.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class CrazyLid extends Lid {
    /**
     * @param cupNumber numero de la taza propietaria (>= 1)
     * @param color     color base (se sobreescribe a green)
     */
    public CrazyLid(int cupNumber, String color) {
        super(cupNumber, color);
        super.setColor("green");
    }
    @Override
    public String getSubtype() { return "crazy"; }
}