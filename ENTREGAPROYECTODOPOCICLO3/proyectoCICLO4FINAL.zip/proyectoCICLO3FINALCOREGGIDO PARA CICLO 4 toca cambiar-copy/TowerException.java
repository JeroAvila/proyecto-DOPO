/**
 * Excepcion propia del simulador de torres apilables.
 * Ciclo 4: se agrega OUT_OF_BOUNDS, CUP_IS_CLOSED, COMPANION_NOT_IN_TOWER.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public class TowerException extends Exception {
    public static final int INVALID_NUMBER        = 1;
    public static final int NO_CUPS               = 2;
    public static final int NO_LIDS               = 3;
    public static final int INVALID_CUP_POSITION  = 4;
    public static final int INVALID_LID_POSITION  = 5;
    public static final int ITEM_NOT_FOUND        = 6;
    public static final int INVALID_TOWER_SIZE    = 7;
    public static final int EMPTY_TOWER           = 8;
    /** Copa removida que no existe / salio del tablero. */
    public static final int OUT_OF_BOUNDS         = 9;
    /** Taza anclada o fearful lid tapando a su taza. */
    public static final int CUP_IS_CLOSED         = 10;
    /** FearfulLid quiere entrar pero su taza no esta en la torre. */
    public static final int COMPANION_NOT_IN_TOWER = 11;
    private int errorCode;
    /**
     * @param errorCode codigo de error (use las constantes de esta clase)
     * @param message   descripcion del error
     */
    public TowerException(int errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }
    /** @return codigo de error tipado */
    public int getErrorCode() {
        return errorCode;
    }
}