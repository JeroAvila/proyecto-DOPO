/**
 * Interfaz que representa cualquier objeto que puede apilarse en la torre.
 * Ciclo 4: se agrega getSubtype() para distinguir variantes sin instanceof.
 *
 * @author Avila - Bernal
 * @version 4 - Ciclo 4
 */
public interface StackableItem {
    int getWidthPixels();
    int getHeightCm();
    int getHeightPixels();
    int getInteriorWidth();
    int getInteriorFloorOffset();
    boolean isContainer();
    /** Tipo base: "cup" o "lid". */
    String getItemType();
    /**
     * Ciclo 4 — Subtipo: "normal", "opener", "hierarchical",
     * "fearful", "crazy", "collapse".
     */
    String getSubtype();
    int getItemNumber();
    void makeVisible();
    void makeInvisible();
    void moveTo(int x, int y);
    void setColor(String color);
    String getColor();
    void notifyCover(boolean covered);
}